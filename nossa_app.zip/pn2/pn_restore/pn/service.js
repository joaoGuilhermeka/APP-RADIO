const TrackPlayer = require("react-native-track-player").default;

module.exports = async function () {
  const { Event } = require("react-native-track-player");

  TrackPlayer.addEventListener(Event.RemotePlay, async () => {
    try {
      const queue = await TrackPlayer.getQueue();
      if (queue.length > 0) {
        const track = queue[0];
        await TrackPlayer.reset();
        await TrackPlayer.add({
          ...track,
          // Sempre manter título fixo na notificação
          title: "Nossa Sertaneja",
          artist: "Ao vivo",
          headers: { "Cache-Control": "no-cache", "Pragma": "no-cache" },
        });
        await TrackPlayer.play();
      } else {
        await TrackPlayer.play();
      }
    } catch {
      await TrackPlayer.play();
    }
  });

  TrackPlayer.addEventListener(Event.RemotePause, async () => {
    await TrackPlayer.pause();
  });

  TrackPlayer.addEventListener(Event.RemoteStop, async () => {
    await TrackPlayer.reset();
  });

  TrackPlayer.addEventListener(Event.RemoteDuck, async (event) => {
    if (event.permanent) await TrackPlayer.pause();
  });
};
