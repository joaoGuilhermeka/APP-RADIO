// Load environment variables with proper priority (system > .env)
import type { ExpoConfig } from "expo/config";

// Bundle ID format: space.manus.<project_name_dots>.<timestamp>
// e.g., "my-app" created at 2024-01-15 10:30:45 -> "space.manus.my.app.t20240115103045"
// Bundle ID can only contain letters, numbers, and dots
// Android requires each dot-separated segment to start with a letter
const bundleId = "com.nossasertaneja.app";
// Extract timestamp from bundle ID for deep link scheme
// e.g., "space.manus.my.app.t20240115103045" -> "nossasertaneja"
const schemeFromBundleId = "nossasertaneja";

const env = {
  // App branding - update these values directly (do not use env vars)
  appName: "Nossa Sertaneja",
  appSlug: "nossa_sertaneja_radio",
  // S3 URL of the app logo - set this to the URL returned by generate_image when creating custom logo
  // Leave empty to use the default icon from assets/images/icon.png
  logoUrl: "https://private-us-east-1.manuscdn.com/sessionFile/hgMp1wMvMpCBQWxxIw8rVR/sandbox/INkSLzdffnXJkhl2KjZAa7-img-1_1770471713000_na1fn_aWNvbg.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvaGdNcDF3TXZNcENCUVd4eEl3OHJWUi9zYW5kYm94L0lOa1NMemRmZm5YSmtobDJLalpBYTctaW1nLTFfMTc3MDQ3MTcxMzAwMF9uYTFmbl9hV052YmcucG5nP3gtb3NzLXByb2Nlc3M9aW1hZ2UvcmVzaXplLHdfMTkyMCxoXzE5MjAvZm9ybWF0LHdlYnAvcXVhbGl0eSxxXzgwIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNzk4NzYxNjAwfX19XX0_&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=rBYxNvHK4-OLrbexryH5FL27kAFoJiOAt5JeEzbgc2QxHdbhl1XR~90jF1KTll3SFMdPId0ggxAARCaTnEg-0ggnMVVhby15sZwhrameNkTcDBV6BA5Q4AzaGH6rSwOd1DlkS4w1gXr2G5x3fu0V5N5h2x2tiy6njBeaBqVCnDXaMaoiIoCc-oEdAKEzEHDh07bHodlO1D043e0VXqh9BQTHY7k4~lxuVysUWyz6ZMQGrDYneLz-~wzdefSJ2qkWQvx72iHR8K2rNPaT2RYO1TtHQhq4gL2wwLqoYu9TtvKIqoS69MrRKtwUDNO9EOxiaVI2fFvH9glbCAVsoo9HAA__",
  scheme: schemeFromBundleId,
  iosBundleId: bundleId,
  androidPackage: bundleId,
};

const config: ExpoConfig = {
  name: env.appName,
  slug: env.appSlug,
  version: "1.0.0",
  orientation: "portrait",
  icon: "./assets/images/icon.png",
  scheme: env.scheme,
  userInterfaceStyle: "automatic",
  newArchEnabled: true,
  ios: {
    supportsTablet: true,
    bundleIdentifier: env.iosBundleId,
    infoPlist: {
      ITSAppUsesNonExemptEncryption: false,
      UIBackgroundModes: ["audio"],
    },
  },
  android: {
    adaptiveIcon: {
      backgroundColor: "#D07600",
      foregroundImage: "./assets/images/android-icon-foreground.png",
      backgroundImage: "./assets/images/android-icon-background.png",
      monochromeImage: "./assets/images/android-icon-monochrome.png",
    },
    edgeToEdgeEnabled: true,
    predictiveBackGestureEnabled: false,
    package: env.androidPackage,
    permissions: [
      "POST_NOTIFICATIONS",
      "FOREGROUND_SERVICE",
      "FOREGROUND_SERVICE_MEDIA_PLAYBACK",
      "WAKE_LOCK",
    ],
    intentFilters: [
      {
        action: "VIEW",
        autoVerify: true,
        data: [
          {
            scheme: env.scheme,
            host: "*",
          },
          {
            scheme: "https",
            host: "nossasertaneja.app",
            pathPrefix: "/",
          },
        ],
        category: ["BROWSABLE", "DEFAULT"],
      },
    ],
  },
  web: {
    bundler: "metro",
    output: "static",
    favicon: "./assets/images/favicon.png",
  },
  plugins: [
    "expo-router",
    "./plugins/withTrackPlayer",
    [
      "expo-video",
      {
        supportsBackgroundPlayback: true,
        supportsPictureInPicture: true,
      },
    ],
    [
      "expo-splash-screen",
      {
        image: "./assets/images/splash-icon.png",
        imageWidth: 1,
        resizeMode: "cover",
        backgroundColor: "#D07600",
        dark: {
          backgroundColor: "#D07600",
        },
      },
    ],
    [
      "expo-build-properties",
      {
        android: {
          buildArchs: ["armeabi-v7a", "arm64-v8a"],
          minSdkVersion: 24,
        },
      },
    ],
  ],
  extra: {
    eas: {
      projectId: "49baa770-24ba-40cf-910b-6e908c9a8aad",
    },
  },
  experiments: {
    typedRoutes: true,
    reactCompiler: false,
  },
};

export default config;
