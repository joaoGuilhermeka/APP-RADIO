import { useState, useEffect, useRef, useCallback } from "react";
import { AppState, type AppStateStatus } from "react-native";
import { Event, useTrackPlayerEvents } from "react-native-track-player";
import type {
  AudioMetadataReceivedEvent,
  AudioCommonMetadataReceivedEvent,
} from "react-native-track-player";

let lastKnownTitle = "";

function isValidTitle(title: string | undefined): title is string {
  if (!title || title.trim().length === 0) return false;
  const lower = title.toLowerCase().trim();
  if (lower === "nossa sertaneja") return false;
  if (lower === "ao vivo") return false;
  if (lower === "rede nossa sertaneja") return false;
  if (lower.startsWith("nossa sertaneja -")) return false;
  if (lower.includes("barbacena")) return false;
  if (lower.includes("997")) return false;
  if (title.trim().length < 3) return false;
  // Filtrar marcadores técnicos do stream ICY (ex: c{play}, c{stop}, [ADV], etc.)
  if (/\{(play|stop|start|end|adv|break)[^}]*\}/i.test(title)) return false;
  if (/^[a-z]\s*\{/i.test(title.trim())) return false;
  return true;
}

export function useLiveMusicNow(isPlaying: boolean, streamUrl?: string) {
  const [music, setMusic] = useState(lastKnownTitle);
  const appStateRef = useRef<AppStateStatus>(AppState.currentState);
  const isMountedRef = useRef(true);

  useEffect(() => {
    isMountedRef.current = true;
    return () => { isMountedRef.current = false; };
  }, []);

  const updateTitle = useCallback((title: string | undefined) => {
    if (!isMountedRef.current || !isValidTitle(title)) return;
    if (title === lastKnownTitle) return;
    console.log("[useLiveMusicNow] ✅ Nova música:", title);
    lastKnownTitle = title;
    setMusic(title);
  }, []);

  // MetadataTimedReceived: array com title, artist
  useTrackPlayerEvents([Event.MetadataTimedReceived], (event) => {
    const e = event as unknown as AudioMetadataReceivedEvent;
    if (!e.metadata || !Array.isArray(e.metadata)) return;
    for (const item of e.metadata) {
      if (isValidTitle(item.title)) {
        const fullTitle = item.artist
          ? `${item.artist} - ${item.title}`
          : item.title!;
        updateTitle(fullTitle);
        return;
      }
    }
  });

  // MetadataCommonReceived: objeto com title, artist
  // Ignorar station — é o nome da rádio, não a música
  useTrackPlayerEvents([Event.MetadataCommonReceived], (event) => {
    const e = event as unknown as AudioCommonMetadataReceivedEvent;
    if (!e.metadata) return;
    const { title, artist } = e.metadata;
    // NÃO usar station — contém "Nossa Sertaneja - Barbacena 997"
    if (isValidTitle(title)) {
      const fullTitle = artist ? `${artist} - ${title}` : title!;
      updateTitle(fullTitle);
    }
  });

  useEffect(() => {
    if (!isPlaying && lastKnownTitle) setMusic(lastKnownTitle);
  }, [isPlaying]);

  useEffect(() => {
    const sub = AppState.addEventListener("change", (nextState) => {
      const wasBackground =
        appStateRef.current === "background" || appStateRef.current === "inactive";
      if (wasBackground && nextState === "active" && lastKnownTitle) {
        setMusic(lastKnownTitle);
      }
      appStateRef.current = nextState;
    });
    return () => sub.remove();
  }, []);

  const refetch = useCallback(() => {
    if (lastKnownTitle) setMusic(lastKnownTitle);
  }, []);

  return { music, isLoading: false, error: null, refetch };
}
