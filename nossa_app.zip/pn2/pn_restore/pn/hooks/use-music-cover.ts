import { useState, useEffect, useRef } from "react";

export interface MusicCover {
  coverUrl: string | null;
  artist: string;
  title: string;
}

const coverCache = new Map<string, MusicCover>();

function cleanTitle(raw: string): string {
  return raw
    .replace(/\s*\(ao vivo\)/gi, "")
    .replace(/\s*\(live\)/gi, "")
    .replace(/\s*\(version\)/gi, "")
    .replace(/\s*\(versão[^)]*\)/gi, "")
    .replace(/\s*\(part\.[^)]*\)/gi, "")
    .replace(/\s*feat\..*/gi, "")
    .trim();
}

async function searchItunes(term: string): Promise<string | null> {
  try {
    const query = encodeURIComponent(term);
    const url = `https://itunes.apple.com/search?term=${query}&media=music&limit=5&country=br`;
    console.log("[useMusicCover] Buscando iTunes:", term);
    const res = await fetch(url, {
      headers: {
        "Accept": "application/json",
      },
    });
    if (!res.ok) {
      console.warn("[useMusicCover] iTunes retornou:", res.status);
      return null;
    }
    const data = await res.json();
    console.log("[useMusicCover] iTunes resultados:", data.resultCount, "para:", term);
    if (data.results && data.results.length > 0) {
      const artwork = data.results[0].artworkUrl100?.replace("100x100bb", "600x600bb") || null;
      console.log("[useMusicCover] Artwork encontrado:", artwork?.substring(0, 60));
      return artwork;
    }
    return null;
  } catch (e) {
    console.warn("[useMusicCover] Erro iTunes:", e);
    return null;
  }
}

export function useMusicCover(musicString: string, onCoverChange?: (coverUrl: string | null) => void) {
  const [cover, setCover] = useState<MusicCover | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const lastMusicRef = useRef<string>("");

  useEffect(() => {
    if (!musicString || musicString === lastMusicRef.current) return;
    lastMusicRef.current = musicString;

    console.log("[useMusicCover] Nova música recebida:", musicString);
    setIsLoading(true);

    const fetchCover = async () => {
      try {
        const parts = musicString.split(" - ");

        let artist = "";
        let title = musicString;

        // Se não tem " - ", é nome de programa, não música
        // Não buscar no iTunes — retornar null para usar imagem do programa
        if (parts.length < 2) {
          console.log("[useMusicCover] Nome de programa detectado, sem busca iTunes:", musicString);
          setCover(null);
          if (onCoverChange) onCoverChange(null);
          setIsLoading(false);
          return;
        }

        artist = parts[0].trim();
        title = cleanTitle(parts.slice(1).join(" - ").trim());

        const cacheKey = `${artist}|${title}`;

        if (coverCache.has(cacheKey)) {
          const cached = coverCache.get(cacheKey)!;
          console.log("[useMusicCover] Cache hit:", cacheKey);
          setCover(cached);
          if (onCoverChange) onCoverChange(cached.coverUrl);
          setIsLoading(false);
          return;
        }

        // Estratégias de busca em ordem
        const strategies = [
          `${artist} ${title}`,
          title,
          musicString.replace(/ - /g, " "),
        ];

        let artworkUrl: string | null = null;

        for (const term of strategies) {
          artworkUrl = await searchItunes(term);
          if (artworkUrl) {
            console.log("[useMusicCover] ✅ Capa encontrada com:", term);
            break;
          }
        }

        if (!artworkUrl) {
          console.warn("[useMusicCover] ❌ Nenhuma capa encontrada para:", musicString);
        }

        const newCover: MusicCover = { coverUrl: artworkUrl, artist, title };
        coverCache.set(cacheKey, newCover);
        setCover(newCover);
        if (onCoverChange) onCoverChange(artworkUrl);
      } catch (e) {
        console.error("[useMusicCover] Erro geral:", e);
        setCover(null);
        if (onCoverChange) onCoverChange(null);
      } finally {
        setIsLoading(false);
      }
    };

    fetchCover();
  }, [musicString, onCoverChange]);

  return { cover, isLoading };
}
