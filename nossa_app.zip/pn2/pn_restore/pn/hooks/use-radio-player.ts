import { useCallback, useEffect, useRef, useState } from "react";
import { Platform, AppState, type AppStateStatus } from "react-native";
import TrackPlayer, {
  Capability,
  Event,
  State,
  usePlaybackState,
  useTrackPlayerEvents,
  RepeatMode,
  AppKilledPlaybackBehavior,
} from "react-native-track-player";

export interface PlayerState {
  isPlaying: boolean;
  isLoading: boolean;
  error: string | null;
  currentStationId: string | null;
}

const LOGO_NOSSA_SERTANEJA_URL =
  "https://files.manuscdn.com/user_upload_by_module/session_file/310519663263634897/hTVISMHmRvSsYFKu.png";

let playerReady = false;

async function setupPlayer() {
  if (playerReady) return;
  try {
    await TrackPlayer.setupPlayer({ maxCacheSize: 0 });
    await TrackPlayer.updateOptions({
      capabilities: [Capability.Play, Capability.Pause, Capability.Stop],
      compactCapabilities: [Capability.Play, Capability.Pause],
      progressUpdateEventInterval: 2,
      android: {
        // Remove notificação e para playback ao fechar o app
        appKilledPlaybackBehavior:
          AppKilledPlaybackBehavior.StopPlaybackAndRemoveNotification,
      },
    });
    await TrackPlayer.setRepeatMode(RepeatMode.Off);
    playerReady = true;
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    if (message.includes("already")) {
      playerReady = true;
    } else {
      console.error("[TrackPlayer] Erro ao inicializar:", error);
    }
  }
}

// Callbacks globais para atualizar artwork
let onMusicChangeCallback: ((coverUrl: string) => void) | null = null;
let onProgramChangeCallback: ((img: string) => void) | null = null;
let currentMusicTitle = "";
let currentProgramName = "";

export function setMusicChangeCallback(callback: (coverUrl: string) => void) {
  onMusicChangeCallback = callback;
}

export function setProgramChangeCallback(callback: (img: string) => void) {
  onProgramChangeCallback = callback;
}

export function updateCurrentMusic(title: string, coverUrl: string) {
  if (title !== currentMusicTitle) {
    currentMusicTitle = title;
    if (onMusicChangeCallback) onMusicChangeCallback(coverUrl);
  }
}

export function updateCurrentProgram(programName: string, programImg: string) {
  if (programName !== currentProgramName) {
    currentProgramName = programName;
    if (onProgramChangeCallback) onProgramChangeCallback(programImg);
  }
}

// Referência global à stream atual para o service.js usar
let currentStreamUrl = "";
let currentStationTitle = "Nossa Sertaneja";
export function getCurrentStreamUrl() { return currentStreamUrl; }
export function getCurrentStationTitle() { return currentStationTitle; }

export function useRadioPlayer() {
  const [state, setState] = useState<PlayerState>({
    isPlaying: false,
    isLoading: false,
    error: null,
    currentStationId: null,
  });

  const currentStationIdRef = useRef<string | null>(null);
  const currentArtworkRef = useRef<string>(LOGO_NOSSA_SERTANEJA_URL);
  const playbackState = usePlaybackState();

  useEffect(() => {
    if (Platform.OS === "web") return;
    setupPlayer();
  }, []);

  // Sincronizar estado TrackPlayer → React
  useEffect(() => {
    if (Platform.OS === "web") return;
    const pbState = playbackState.state;
    if (pbState === State.Playing) {
      setState((prev) => ({ ...prev, isPlaying: true, isLoading: false, error: null }));
    } else if (pbState === State.Buffering || pbState === State.Loading) {
      setState((prev) => ({ ...prev, isLoading: true, isPlaying: false }));
    } else if (pbState === State.Paused || pbState === State.Stopped || pbState === State.Ready || pbState === State.None) {
      setState((prev) => ({ ...prev, isPlaying: false, isLoading: false }));
    } else if (pbState === State.Error) {
      setState((prev) => ({ ...prev, isPlaying: false, isLoading: false, error: "Erro ao reproduzir" }));
    }
  }, [playbackState.state]);

  useTrackPlayerEvents([Event.PlaybackError], () => {
    setState((prev) => ({ ...prev, isPlaying: false, isLoading: false, error: "Erro ao conectar" }));
  });

  // Notificação sempre usa logo fixa — nunca atualiza com capa da música
  const updateLockScreenWithArtwork = useCallback(async (_artworkUrl: string) => {
    // Intencionalmente vazio — notificação mantém logo do microfone sempre
  }, []);

  useEffect(() => {
    setMusicChangeCallback(() => {}); // não atualiza notificação
    setProgramChangeCallback(() => {}); // não atualiza notificação
  }, []);

  const play = useCallback(
    async (stationId: string, streamUrl: string, stationName?: string) => {
      if (Platform.OS === "web") return;

      // Guardar referências globais para o service.js usar
      currentStreamUrl = streamUrl;
      currentStationTitle = stationName || "Nossa Sertaneja";
      currentArtworkRef.current = LOGO_NOSSA_SERTANEJA_URL;
      currentStationIdRef.current = stationId;

      setState((prev) => ({
        ...prev,
        isLoading: true,
        error: null,
        currentStationId: stationId,
      }));

      try {
        await setupPlayer();
        // Sempre reset + add para garantir reconexão no ponto AO VIVO atual
        await TrackPlayer.reset();
        await TrackPlayer.add({
          id: stationId,
          url: streamUrl,
          title: "Nossa Sertaneja",
          artist: "Ao vivo",
          artwork: LOGO_NOSSA_SERTANEJA_URL,
          isLiveStream: true,
          headers: { "Cache-Control": "no-cache", Pragma: "no-cache" },
        });
        await TrackPlayer.play();
      } catch (error) {
        const msg = error instanceof Error ? error.message : "Erro ao conectar";
        setState((prev) => ({ ...prev, isPlaying: false, isLoading: false, error: msg }));
      }
    },
    []
  );

  const pause = useCallback(async () => {
    if (Platform.OS === "web") return;
    try {
      // Pausar mas MANTER a notificação ativa (para o usuário poder dar play de novo)
      // NÃO chamar reset() aqui — só pausar
      await TrackPlayer.pause();
    } catch (_) {}
  }, []);

  const stop = useCallback(async () => {
    if (Platform.OS === "web") return;
    currentStationIdRef.current = null;
    setState((prev) => ({ ...prev, isPlaying: false, isLoading: false, error: null, currentStationId: null }));
    try {
      await TrackPlayer.reset();
    } catch (_) {}
  }, []);

  return { state, play, pause, stop, updateLockScreenWithArtwork };
}
