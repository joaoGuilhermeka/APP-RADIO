import { useState, useEffect, useRef, useCallback } from "react";

export interface NowPlaying {
  artist: string;
  title: string;
  isRealSong: boolean;
}

// Palavras que indicam que não é uma música real
const STATION_KEYWORDS = [
  "nossa sertaneja",
  "vozdobrasil",
  "voz do brasil",
  "rede sertaneja",
  "transcoder",
  "stream",
];

function isRealSongTitle(songTitle: string): boolean {
  if (!songTitle || !songTitle.includes(" - ")) return false;
  const lower = songTitle.toLowerCase();
  return !STATION_KEYWORDS.some((kw) => lower.includes(kw));
}

// Busca capa no iTunes
async function searchCover(artist: string, title: string): Promise<string | null> {
  try {
    const query = encodeURIComponent(`${artist} ${title}`);
    const response = await fetch(
      `https://itunes.apple.com/search?term=${query}&media=music&limit=1&country=br`
    );
    const data = await response.json();
    if (data.results && data.results.length > 0) {
      return data.results[0].artworkUrl100.replace("100x100bb", "600x600bb");
    }
    return null;
  } catch {
    return null;
  }
}

// Tenta extrair SONGTITLE do XML do Shoutcast
function parseSongTitleFromXML(xml: string): string | null {
  const match = xml.match(/<SONGTITLE>(.*?)<\/SONGTITLE>/i);
  return match ? match[1].trim() : null;
}

// Tenta extrair do JSON do Icecast
function parseSongTitleFromJSON(json: any): string | null {
  try {
    const sources = json?.icestats?.source;
    if (sources) {
      const src = Array.isArray(sources) ? sources[0] : sources;
      if (src?.title || src?.artist) {
        return `${src.artist || ""} - ${src.title || ""}`.trim();
      }
    }
    if (json?.title) return json.title;
    if (json?.song) return json.song;
    if (json?.current_song) return json.current_song;
    return null;
  } catch {
    return null;
  }
}

export function useNowPlaying(statsUrl: string, isPlaying: boolean) {
  const [nowPlaying, setNowPlaying] = useState<NowPlaying | null>(null);
  const [coverUrl, setCoverUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const lastSongRef = useRef<string>("");
  const isMountedRef = useRef(true);

  useEffect(() => {
    isMountedRef.current = true;
    return () => { isMountedRef.current = false; };
  }, []);

  const fetchStats = useCallback(async () => {
    if (!statsUrl || !isMountedRef.current) return;

    try {
      setIsLoading(true);

      const response = await fetch(statsUrl, {
        headers: { "Cache-Control": "no-cache", "Pragma": "no-cache" },
        cache: "no-store",
      });

      if (!isMountedRef.current) return;

      if (!response.ok) {
        setNowPlaying(null);
        setCoverUrl(null);
        return;
      }

      const contentType = response.headers.get("content-type") || "";
      let songTitle: string | null = null;

      if (contentType.includes("json")) {
        const json = await response.json();
        songTitle = parseSongTitleFromJSON(json);
      } else {
        const text = await response.text();
        songTitle = parseSongTitleFromXML(text);
        if (!songTitle) {
          try {
            const json = JSON.parse(text);
            songTitle = parseSongTitleFromJSON(json);
          } catch {
            // não é JSON
          }
        }
      }

      if (!isMountedRef.current) return;

      if (!songTitle) {
        setNowPlaying(null);
        setCoverUrl(null);
        return;
      }

      if (isRealSongTitle(songTitle)) {
        const [artist, ...titleParts] = songTitle.split(" - ");
        const title = titleParts.join(" - ").trim();
        const artistClean = artist.trim();

        setNowPlaying({ artist: artistClean, title, isRealSong: true });

        // Busca capa se a música mudou
        const songKey = `${artistClean}|${title}`;
        if (songKey !== lastSongRef.current) {
          lastSongRef.current = songKey;
          // Busca capa em background
          searchCover(artistClean, title).then((cover) => {
            if (isMountedRef.current) {
              setCoverUrl(cover);
            }
          });
        }
      } else {
        setNowPlaying({ artist: "", title: songTitle, isRealSong: false });
        setCoverUrl(null);
        lastSongRef.current = "";
      }
    } catch {
      if (isMountedRef.current) {
        setNowPlaying(null);
        setCoverUrl(null);
      }
    } finally {
      if (isMountedRef.current) setIsLoading(false);
    }
  }, [statsUrl]);

  useEffect(() => {
    if (!isPlaying) {
      // Ao pausar: apenas para o polling, mas MANTÉM a capa e nowPlaying visíveis
      return;
    }

    // Busca imediatamente ao começar a tocar
    fetchStats();
    // Depois a cada 10 segundos (mais frequente para pegar mudanças de música)
    const interval = setInterval(fetchStats, 10000);
    return () => clearInterval(interval);
  }, [statsUrl, isPlaying, fetchStats]);

  // Limpa capa apenas quando muda de estação (statsUrl muda)
  useEffect(() => {
    setNowPlaying(null);
    setCoverUrl(null);
    lastSongRef.current = "";
  }, [statsUrl]);

  return { nowPlaying, coverUrl, isLoading, refresh: fetchStats };
}
