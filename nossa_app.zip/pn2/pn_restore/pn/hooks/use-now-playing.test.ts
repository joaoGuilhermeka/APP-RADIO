import { describe, it, expect } from "vitest";

describe("useNowPlaying", () => {
  it("should parse song info correctly with artist and title separated by dash", () => {
    const songTitle = "Chitãozinho & Xororó - Evidências";
    const [artist, title] = songTitle.split(" - ");
    
    expect(artist.trim()).toBe("Chitãozinho & Xororó");
    expect(title.trim()).toBe("Evidências");
  });

  it("should handle song title without separator", () => {
    const songTitle = "Evidências";
    const hasArtist = songTitle.includes(" - ");
    
    expect(hasArtist).toBe(false);
  });

  it("should construct iTunes search URL correctly", () => {
    const artist = "Chitãozinho & Xororó";
    const title = "Evidências";
    const searchQuery = `${artist} ${title}`;
    const encodedQuery = encodeURIComponent(searchQuery);
    const url = `https://itunes.apple.com/search?term=${encodedQuery}&media=music&limit=1`;
    
    expect(url).toContain("Chit%C3%A3ozinho");
    expect(url).toContain("Evid%C3%AAncias");
    expect(url).toContain("media=music");
    expect(url).toContain("limit=1");
  });

  it("should convert stream URL to stats URL correctly", () => {
    const streamUrl = "http://radio.audiosolutions.tech:8200/stream";
    const statsUrl = streamUrl.replace("/stream", "/stats");
    
    expect(statsUrl).toBe("http://radio.audiosolutions.tech:8200/stats");
  });

  it("should upgrade artwork URL to higher quality", () => {
    const artworkUrl100 = "https://is1-ssl.mzstatic.com/image/thumb/Music/v4/12/34/56/12345678.jpg/100x100bb.jpg";
    const artworkUrl600 = artworkUrl100.replace("100x100", "600x600");
    
    expect(artworkUrl600).toContain("600x600");
    expect(artworkUrl600).not.toContain("100x100");
  });
});
