import { useEffect, useRef, useCallback } from "react";
import * as Notifications from "expo-notifications";
import { Platform, AppState, type AppStateStatus } from "react-native";

interface PlaybackNotificationOptions {
  stationName: string;
  frequency: string;
  isPlaying: boolean;
  songTitle?: string;
  onPlay?: () => void;
  onPause?: () => void;
}

const CHANNEL_ID = "radio_playback";
const NOTIFICATION_ID = "radio_playback_persistent";
const CATEGORY_PLAYING = "RADIO_PLAYING";
const CATEGORY_PAUSED = "RADIO_PAUSED";

// Não mostrar alerta quando app está em foreground
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: false,
    shouldPlaySound: false,
    shouldSetBadge: false,
    shouldShowBanner: false,
    shouldShowList: false,
  }),
});

let channelSetup = false;

async function setupChannel() {
  if (Platform.OS !== "android") return;
  if (channelSetup) return;

  await Notifications.setNotificationChannelAsync(CHANNEL_ID, {
    name: "Nossa Sertaneja - Rádio",
    importance: Notifications.AndroidImportance.LOW,
    vibrationPattern: [0],
    enableVibrate: false,
    enableLights: false,
    showBadge: false,
    sound: null,
    lockscreenVisibility: Notifications.AndroidNotificationVisibility.PUBLIC,
  });

  // Categoria quando está TOCANDO → botão Pausar
  await Notifications.setNotificationCategoryAsync(CATEGORY_PLAYING, [
    {
      identifier: "PAUSE",
      buttonTitle: "⏸ Pausar",
      options: { opensAppToForeground: false },
    },
  ]);

  // Categoria quando está PAUSADO → botão Play
  await Notifications.setNotificationCategoryAsync(CATEGORY_PAUSED, [
    {
      identifier: "PLAY",
      buttonTitle: "▶ Tocar",
      options: { opensAppToForeground: false },
    },
  ]);

  channelSetup = true;
}

async function showNotification(songTitle?: string, frequency?: string, isPlaying = true) {
  if (Platform.OS !== "android") return;

  const body = songTitle && songTitle.trim()
    ? songTitle
    : (frequency || "Ao vivo");

  const title = isPlaying ? "🎵 Nossa Sertaneja" : "⏸ Nossa Sertaneja (pausado)";
  const category = isPlaying ? CATEGORY_PLAYING : CATEGORY_PAUSED;

  try {
    await Notifications.cancelScheduledNotificationAsync(NOTIFICATION_ID).catch(() => {});
  } catch (_) {}

  await Notifications.scheduleNotificationAsync({
    identifier: NOTIFICATION_ID,
    content: {
      title,
      body,
      sound: false,
      sticky: true,
      priority: "low",
      badge: 0,
      categoryIdentifier: category,
      data: { type: "radio_playback" },
    },
    trigger: null,
  });
}

async function dismissNotification() {
  if (Platform.OS !== "android") return;
  try {
    await Notifications.cancelScheduledNotificationAsync(NOTIFICATION_ID);
  } catch (_) {}
  try {
    await Notifications.dismissAllNotificationsAsync();
  } catch (_) {}
}

export function usePlaybackNotification({
  frequency,
  isPlaying,
  songTitle,
  onPlay,
  onPause,
}: PlaybackNotificationOptions) {
  const appState = useRef<AppStateStatus>(AppState.currentState);
  const isPlayingRef = useRef(isPlaying);
  const songTitleRef = useRef(songTitle);
  const frequencyRef = useRef(frequency);
  isPlayingRef.current = isPlaying;
  songTitleRef.current = songTitle;
  frequencyRef.current = frequency;

  // Setup inicial
  useEffect(() => {
    if (Platform.OS !== "android") return;
    setupChannel();
    Notifications.requestPermissionsAsync().catch(() => {});
  }, []);

  // Listener para botões Play/Pause na notificação
  useEffect(() => {
    if (Platform.OS !== "android") return;

    const sub = Notifications.addNotificationResponseReceivedListener((response) => {
      const action = response.actionIdentifier;
      if (action === "PAUSE" && onPause) {
        onPause();
      } else if (action === "PLAY" && onPlay) {
        onPlay();
      }
    });

    return () => sub.remove();
  }, [onPlay, onPause]);

  // Mostra/atualiza notificação conforme estado de reprodução
  useEffect(() => {
    if (Platform.OS !== "android") return;
    // Sempre mostra a notificação (tocando ou pausado) com o botão correto
    showNotification(songTitle, frequency, isPlaying);
  }, [isPlaying, songTitle, frequency]);

  // Garante notificação ao ir para background (só se tocando)
  useEffect(() => {
    if (Platform.OS !== "android") return;

    const sub = AppState.addEventListener("change", (nextState) => {
      const wasActive = appState.current === "active";
      const goingBackground = nextState === "background" || nextState === "inactive";
      const comingForeground = nextState === "active";

      if (wasActive && goingBackground) {
        // Reforça notificação ao minimizar (tocando ou pausado)
        showNotification(songTitleRef.current, frequencyRef.current, isPlayingRef.current);
      }

      appState.current = nextState;
    });

    return () => sub.remove();
  }, [songTitle, frequency]);

  // Remove notificação ao desmontar (app fechado)
  useEffect(() => {
    return () => {
      dismissNotification();
    };
  }, []);
}
