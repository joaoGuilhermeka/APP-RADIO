import { useState, useEffect } from "react";
import { programacaoSemanal, getCurrentDayKey, type DayKey, type Program } from "@/lib/programming-schedule";

export function useLiveProgram() {
  const [liveProgram, setLiveProgram] = useState<Program | null>(null);
  const [currentDay, setCurrentDay] = useState<DayKey>(getCurrentDayKey());

  useEffect(() => {
    const updateLiveProgram = () => {
      const now = new Date();
      const dayKey = getCurrentDayKey();
      const currentTime = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;

      setCurrentDay(dayKey);

      const programs = programacaoSemanal[dayKey];
      const currentProgram = programs.find((program: Program) => {
        if (program.fim === "00:00") {
          return currentTime >= program.inicio;
        }
        return currentTime >= program.inicio && currentTime < program.fim;
      });

      setLiveProgram(currentProgram || programs[0] || null);
    };

    updateLiveProgram();
    const interval = setInterval(updateLiveProgram, 60000);
    return () => clearInterval(interval);
  }, []);

  return { liveProgram, currentDay };
}
