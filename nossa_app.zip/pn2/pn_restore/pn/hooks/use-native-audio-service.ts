import { useCallback, useEffect, useRef, useState } from "react";
import { Platform, AppState, type AppStateStatus } from "react-native";
import AudioServiceModule from "@/lib/audio-service-module";

export interface NativeAudioState {
  isPlaying: boolean;
  isLoading: boolean;
  error: string | null;
  currentStationId: string | null;
}

/**
 * Hook para usar AudioService nativo Android
 * 
 * Diferenças vs expo-audio:
 * - Usa serviço Android nativo com MediaSession correto
 * - Samsung One UI renderiza controles corretamente
 * - Sem dependência de expo-audio
 * 
 * IMPORTANTE: Logo fixa da Nossa Sertaneja (tamanho original - perfeito para Media Session)
 * Fundo branco - compatível com Media Session Samsung
 */
const LOGO_NOSSA_SERTANEJA = "https://files.manuscdn.com/user_upload_by_module/session_file/310519663263634897/hTVISMHmRvSsYFKu.png";
export function useNativeAudioService() {
  const [state, setState] = useState<NativeAudioState>({
    isPlaying: false,
    isLoading: false,
    error: null,
    currentStationId: null,
  });

  const currentStationIdRef = useRef<string | null>(null);
  const appStateRef = useRef<AppStateStatus>("active");
  const appStateSubscriptionRef = useRef<any>(null);

  // Cleanup ao desmontar
  useEffect(() => {
    return () => {
      if (Platform.OS !== "android") return;

      try {
        AudioServiceModule.stop();
      } catch (error) {
        console.error("[useNativeAudioService] Erro ao parar:", error);
      }
    };
  }, []);

  // AppState listener para cleanup ao fechar app
  useEffect(() => {
    if (Platform.OS !== "android") return;

    const handleAppStateChange = (nextAppState: AppStateStatus) => {
      const previousState = appStateRef.current;
      appStateRef.current = nextAppState;

      console.log(
        `[useNativeAudioService] AppState: ${previousState} → ${nextAppState}`
      );

      // App foi removido da multitarefa
      if (previousState === "active" && nextAppState === "unknown") {
        console.log("[useNativeAudioService] App sendo fechado - parando reprodução");

        try {
          AudioServiceModule.stop();
          currentStationIdRef.current = null;
          setState((prev) => ({
            ...prev,
            isPlaying: false,
          }));
        } catch (error) {
          console.error("[useNativeAudioService] Erro ao parar:", error);
        }
      }
    };

    appStateSubscriptionRef.current = AppState.addEventListener(
      "change",
      handleAppStateChange
    );

    return () => {
      if (appStateSubscriptionRef.current) {
        appStateSubscriptionRef.current.remove();
        appStateSubscriptionRef.current = null;
      }
    };
  }, []);

  const play = useCallback(
    async (
      stationId: string,
      streamUrl: string,
      stationName?: string
    ) => {
      if (Platform.OS !== "android") {
        console.warn("[useNativeAudioService] Apenas disponível em Android");
        return;
      }

      currentStationIdRef.current = stationId;

      setState((prev) => ({
        ...prev,
        isLoading: true,
        error: null,
        currentStationId: stationId,
      }));

      try {
        await AudioServiceModule.playStream(
          streamUrl,
          stationName || "Nossa Sertaneja",
          "Ao vivo",
          LOGO_NOSSA_SERTANEJA
        );

        setState((prev) => ({
          ...prev,
          isPlaying: true,
          isLoading: false,
          error: null,
        }));

        console.log("[useNativeAudioService] ✓ Play iniciado para estação:", stationId);
      } catch (error) {
        const msg =
          error instanceof Error ? error.message : "Erro ao conectar a estacao";
        setState((prev) => ({
          ...prev,
          isPlaying: false,
          isLoading: false,
          error: msg,
        }));
        console.error("[useNativeAudioService] ❌ Erro ao tocar:", error);
      }
    },
    []
  );

  const pause = useCallback(async () => {
    if (Platform.OS !== "android") return;

    try {
      await AudioServiceModule.pause();
      setState((prev) => ({
        ...prev,
        isPlaying: false,
      }));
      console.log("[useNativeAudioService] ✓ Pausa executada");
    } catch (error) {
      console.error("[useNativeAudioService] ❌ Erro ao pausar:", error);
    }
  }, []);

  const resume = useCallback(async () => {
    if (Platform.OS !== "android") return;

    try {
      await AudioServiceModule.resume();
      setState((prev) => ({
        ...prev,
        isPlaying: true,
      }));
      console.log("[useNativeAudioService] ✓ Retomada executada");
    } catch (error) {
      console.error("[useNativeAudioService] ❌ Erro ao retomar:", error);
    }
  }, []);

  const stop = useCallback(async () => {
    if (Platform.OS !== "android") return;

    currentStationIdRef.current = null;

    try {
      await AudioServiceModule.stop();
      setState((prev) => ({
        ...prev,
        isPlaying: false,
        isLoading: false,
        error: null,
        currentStationId: null,
      }));
      console.log("[useNativeAudioService] ✓ Stop executado");
    } catch (error) {
      console.error("[useNativeAudioService] ❌ Erro ao parar:", error);
    }
  }, []);

  return {
    state,
    play,
    pause,
    resume,
    stop,
  };
}
