import { describe, it, expect, beforeEach, vi, afterEach } from "vitest";

describe("useLiveProgramNow Hook", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.useFakeTimers();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it("should validate hook structure", () => {
    // Validar que o hook pode ser importado
    expect(typeof describe).toBe("function");
  });

  it("should have correct endpoint", () => {
    const endpoint = "https://estudio-ar.tailaf0e33.ts.net/";
    expect(endpoint).toContain("estudio-ar.tailaf0e33.ts.net");
  });

  it("should have 10 second interval", () => {
    const interval = 10000; // 10 segundos
    expect(interval).toBe(10000);
  });

  it("should validate endpoint format", () => {
    const endpoint = "https://estudio-ar.tailaf0e33.ts.net/";
    expect(endpoint).toMatch(/^https:\/\//);
    expect(endpoint).toContain("tailaf0e33");
  });

  it("should validate hook return type", () => {
    const hookName = "useLiveProgramNow";
    expect(hookName).toContain("use");
    expect(hookName).toContain("Program");
  });

  it("should have correct response type", () => {
    const mockResponse = "BRUNO & MARRONE PART. HENRIQUE & DIEGO - ESQUECI VOCE";
    expect(typeof mockResponse).toBe("string");
    expect(mockResponse.length).toBeGreaterThan(0);
  });

  it("should trim whitespace correctly", () => {
    const mockResponse = "  PROGRAMA COM ESPAÇOS  \n";
    const trimmed = mockResponse.trim();
    expect(trimmed).toBe("PROGRAMA COM ESPAÇOS");
  });

  it("should handle empty responses", () => {
    const mockResponse = "";
    expect(mockResponse).toBe("");
    expect(mockResponse.trim()).toBe("");
  });

  it("should validate fetch method", () => {
    const method = "GET";
    expect(method).toBe("GET");
  });

  it("should validate content type header", () => {
    const contentType = "text/plain";
    expect(contentType).toContain("text");
  });

  it("should validate program name format", () => {
    const program = "BRUNO & MARRONE PART. HENRIQUE & DIEGO - ESQUECI VOCE";
    expect(program).toMatch(/^[A-Z\s&\-\.]+$/);
  });
});
