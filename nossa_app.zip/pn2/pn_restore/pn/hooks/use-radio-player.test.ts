import { describe, it, expect, beforeEach, vi } from "vitest";

// Mock expo-audio
vi.mock("expo-audio", () => {
  return {
    useAudioPlayer: vi.fn(() => ({
      play: vi.fn().mockResolvedValue(undefined),
      pause: vi.fn().mockResolvedValue(undefined),
      release: vi.fn().mockResolvedValue(undefined),
    })),
    setAudioModeAsync: vi.fn().mockResolvedValue(undefined),
  };
});

// Mock expo-haptics
vi.mock("expo-haptics", () => {
  return {
    impactAsync: vi.fn().mockResolvedValue(undefined),
    ImpactFeedbackStyle: {
      Light: 0,
    },
  };
});

describe("Radio Player Hook", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("should validate radio stations data structure", () => {
    const mockStation = {
      id: "test-station",
      name: "Test Station",
      streamUrl: "https://example.com/stream",
      statsUrl: "https://example.com/stats",
    };

    expect(mockStation.id).toBeDefined();
    expect(mockStation.name).toBeDefined();
    expect(mockStation.streamUrl).toBeDefined();
    expect(mockStation.statsUrl).toBeDefined();
  });

  it("should validate player state structure", () => {
    const mockState = {
      isPlaying: false,
      isLoading: false,
      error: null,
      currentStationId: null,
    };

    expect(mockState.isPlaying).toBe(false);
    expect(mockState.isLoading).toBe(false);
    expect(mockState.error).toBeNull();
    expect(mockState.currentStationId).toBeNull();
  });
});
