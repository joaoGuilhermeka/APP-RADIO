import { describe, it, expect } from "vitest";

describe("useLiveMusicNow - ICY Metadata Extraction", () => {
  // Simular a função extractMetadata do hook
  const extractMetadata = (data: Uint8Array): string | null => {
    try {
      const text = new TextDecoder("utf-8", { fatal: false }).decode(data);
      
      const streamTitleMatch = text.match(/StreamTitle='([^']*)'/);
      if (streamTitleMatch && streamTitleMatch[1]) {
        return streamTitleMatch[1].trim();
      }

      const altMatch = text.match(/StreamTitle=([^;]+)/);
      if (altMatch && altMatch[1]) {
        return altMatch[1].replace(/['"]\s*/g, "").trim();
      }

      return null;
    } catch (err) {
      console.error("[extractMetadata] Error:", err);
      return null;
    }
  };

  describe("extractMetadata", () => {
    it("deve extrair StreamTitle no formato padrão ICY", () => {
      const data = new TextEncoder().encode("StreamTitle='Sertanejo Hits - Festa na Roça';");
      const result = extractMetadata(data);
      expect(result).toBe("Sertanejo Hits - Festa na Roça");
    });

    it("deve extrair StreamTitle com caracteres especiais", () => {
      const data = new TextEncoder().encode("StreamTitle='João & Maria - Amor Sertanejo';");
      const result = extractMetadata(data);
      expect(result).toBe("João & Maria - Amor Sertanejo");
    });

    it("deve extrair StreamTitle em formato alternativo", () => {
      const data = new TextEncoder().encode('StreamTitle="Programa Ao Vivo";');
      const result = extractMetadata(data);
      expect(result).toBe("Programa Ao Vivo");
    });

    it("deve retornar null quando não houver StreamTitle", () => {
      const data = new TextEncoder().encode("icy-name: Nossa Sertaneja");
      const result = extractMetadata(data);
      expect(result).toBeNull();
    });

    it("deve extrair StreamTitle mesmo com dados binários antes", () => {
      // Simular dados binários seguidos de metadados ICY
      const binaryData = new Uint8Array([0xFF, 0xFB, 0x10, 0x00]); // Cabeçalho MP3
      const metadataText = new TextEncoder().encode("StreamTitle='Música ao Vivo';");
      const combined = new Uint8Array([...binaryData, ...metadataText]);
      const result = extractMetadata(combined);
      expect(result).toBe("Música ao Vivo");
    });

    it("deve extrair StreamTitle com espaços em branco", () => {
      const data = new TextEncoder().encode("  StreamTitle='  Sertanejo Clássico  ';  ");
      const result = extractMetadata(data);
      expect(result).toBe("Sertanejo Clássico");
    });

    it("deve retornar null para dados vazios", () => {
      const data = new Uint8Array(0);
      const result = extractMetadata(data);
      expect(result).toBeNull();
    });

    it("deve extrair StreamTitle com múltiplas linhas de metadados", () => {
      const data = new TextEncoder().encode(
        "icy-br:64\n" +
        "icy-name:Nossa Sertaneja\n" +
        "StreamTitle='Festa Sertaneja - Ao Vivo';\n" +
        "icy-url:http://example.com"
      );
      const result = extractMetadata(data);
      expect(result).toBe("Festa Sertaneja - Ao Vivo");
    });
  });

  describe("brasilstream integration", () => {
    it("deve extrair corretamente metadados do stream real", () => {
      // Simulando resposta real do brasilstream
      const realStreamMetadata = new TextEncoder().encode(
        "StreamTitle='Nossa Sertaneja - Sete Lagoas 1077';"
      );
      const result = extractMetadata(realStreamMetadata);
      expect(result).toBe("Nossa Sertaneja - Sete Lagoas 1077");
    });
  });
});
