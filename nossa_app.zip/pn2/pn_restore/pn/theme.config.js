/** @type {const} */
const themeColors = {
  primary: { light: '#D07600', dark: '#D07600' },
  background: { light: '#D07600', dark: '#D07600' },
  surface: { light: '#2C3E50', dark: '#2C3E50' },
  foreground: { light: '#FFFFFF', dark: '#FFFFFF' },
  muted: { light: '#E0E0E0', dark: '#BDBDBD' },
  border: { light: '#FFFFFF', dark: '#FFFFFF' },
  success: { light: '#7CB342', dark: '#7CB342' },
  warning: { light: '#FFA726', dark: '#FFB74D' },
  error: { light: '#EF5350', dark: '#E57373' },
};

module.exports = { themeColors };
