import { Redirect } from "expo-router";

/**
 * Rota de fallback - redireciona qualquer rota não encontrada para a tela principal.
 * Isso resolve o "Unmatched Route" ao clicar na notificação do TrackPlayer.
 */
export default function NotFoundScreen() {
  return <Redirect href="/(tabs)" />;
}
