import { useCallback, useRef, useState } from "react";
import { useFocusEffect, useRouter } from "expo-router";
import { WebView } from "react-native-webview";
import { ScreenContainer } from "@/components/screen-container";
import { RadioDrawer } from "@/components/radio-drawer";
import { View, Text, Image, TouchableOpacity, Share, Platform, Dimensions, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";

const STREAM_URL = "https://player.jmvstream.com/lvw/hCk4wZXJ7khxcrkcV0yLt5cSNH7JkS";

const streamHTML = `
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    html, body {
      width: 100%;
      height: 100%;
      background: #000;
      overflow: hidden;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    iframe {
      width: 100%;
      height: 100%;
      border: none;
      display: block;
    }
  </style>
</head>
<body>
  <iframe
    src="${STREAM_URL}"
    frameborder="0"
    allow="autoplay; fullscreen"
    allowfullscreen>
  </iframe>
</body>
</html>
`;

export default function TVScreen() {
  const router = useRouter();
  const { width: screenWidth, height: screenHeight } = Dimensions.get("window");
  
  const videoHeight = screenWidth * (9 / 16);
  const webViewRef = useRef<WebView>(null);
  const [showStationsModal, setShowStationsModal] = useState(false);

  const isSmallScreen = screenWidth < 380;
  const isMediumScreen = screenWidth >= 380 && screenWidth < 480;
  const usableWidth = screenWidth - 32;

  let logoWidth: number;
  if (isSmallScreen) {
    logoWidth = Math.min(usableWidth * 0.8, 280);
  } else if (isMediumScreen) {
    logoWidth = Math.min(usableWidth * 0.7, 300);
  } else {
    logoWidth = Math.min(usableWidth * 0.6, 320);
  }
  const logoHeight = logoWidth * 0.8;
  const headerHeight = 60;
  const headerPadding = 8;

  const handleShare = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    try {
      await Share.share({
        message: `Estou assistindo Nossa Sertaneja TV 📺`,
        title: "Nossa Sertaneja Rádio",
      });
    } catch (_) {}
  };

  useFocusEffect(
    useCallback(() => {
      return () => {
        if (webViewRef.current && Platform.OS !== "web") {
          webViewRef.current.injectJavaScript("document.querySelector('iframe').src = document.querySelector('iframe').src;");
        }
      };
    }, [])
  );

  return (
    <ScreenContainer edges={["top", "left", "right"]} className="bg-[#D07600]">
      {/* Header com Menu, Logo e Compartilhar */}
      <View
        style={{
          height: headerHeight,
          paddingHorizontal: headerPadding,
          paddingVertical: 4,
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between",
          zIndex: 1,
          overflow: "visible",
          position: "relative",
        }}
      >
        <TouchableOpacity
          onPress={() => setShowStationsModal(true)}
          style={{
            padding: 10,
            zIndex: 1100,
            position: "absolute",
            left: 8,
            top: 10,
          }}
          hitSlop={{ top: 20, bottom: 20, left: 20, right: 20 }}
        >
          <Ionicons name="menu" size={32} color="#FFFFFF" />
        </TouchableOpacity>

        <Image
          source={require("@/assets/images/logo-transparent.png")}
          style={{
            width: logoWidth,
            height: logoHeight,
            position: "absolute",
            left: screenWidth / 2,
            marginLeft: -logoWidth / 2,
            top: headerHeight / 2 - logoHeight / 2 + 20,
            zIndex: 10,
          }}
          resizeMode="contain"
        />

        <TouchableOpacity
          onPress={handleShare}
          style={{
            padding: 10,
            zIndex: 1100,
            position: "absolute",
            right: 8,
            top: 10,
          }}
          hitSlop={{ top: 20, bottom: 20, left: 20, right: 20 }}
        >
          <Ionicons name="share-social" size={32} color="#FFFFFF" />
        </TouchableOpacity>
      </View>

      {/* Conteúdo Centralizado Perfeitamente */}
      <View style={styles.container}>
        <View style={[styles.playerContainer, { height: Math.min(videoHeight, screenHeight * 0.55) }]}>
          {Platform.OS === "web" ? (
            <View style={styles.webContainer}>
              <iframe
                src={STREAM_URL}
                style={{ width: "100%", height: "100%", border: "none" }}
                allow="autoplay; fullscreen"
                allowFullScreen
              />
            </View>
          ) : (
            <WebView
              ref={webViewRef}
              source={{ html: streamHTML }}
              style={styles.webview}
              allowsFullscreenVideo
              mediaPlaybackRequiresUserAction={false}
              javaScriptEnabled
              domStorageEnabled
              allowsInlineMediaPlayback
              startInLoadingState
              renderLoading={() => (
                <View style={styles.loadingContainer}>
                  <Text style={styles.loadingText}>Carregando transmissão...</Text>
                </View>
              )}
            />
          )}
        </View>
      </View>

      {/* Mini Player Sincronizado para Páginas Secundárias */}

      {/* Drawer Compartilhado */}
      <RadioDrawer
        visible={showStationsModal}
        onClose={() => setShowStationsModal(false)}
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 16,
    paddingBottom: 40,
  },
  playerContainer: {
    width: "100%",
    maxWidth: 640,
    borderRadius: 18,
    overflow: "hidden",
    backgroundColor: "#000",
    elevation: 10,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.4,
    shadowRadius: 10,
  },
  webContainer: {
    width: "100%",
    height: "100%",
  },
  webview: {
    flex: 1,
    backgroundColor: "#000",
  },
  loadingContainer: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#000",
  },
  loadingText: {
    color: "#FFFFFF",
    fontSize: 14,
  },
});
