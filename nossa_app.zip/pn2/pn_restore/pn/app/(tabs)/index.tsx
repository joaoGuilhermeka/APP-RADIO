import { View, Text, Image, TouchableOpacity, Modal, FlatList, Pressable, Dimensions, ScrollView, Linking, Share, AppState, PixelRatio, type AppStateStatus, useWindowDimensions } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useState, useEffect, useRef } from "react";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";

import { ScreenContainer } from "@/components/screen-container";
import { RadioDrawer } from "@/components/radio-drawer";
import { useRouter } from "expo-router";

import { useRadioPlayer, updateCurrentMusic, updateCurrentProgram } from "@/hooks/use-radio-player";
import { useNowPlaying } from "@/hooks/use-now-playing";
import { useLiveProgram } from "@/hooks/use-live-program";
import { useLiveMusicNow } from "@/hooks/use-live-program-now";
import { useMusicCover } from "@/hooks/use-music-cover";

import { radioStations, type RadioStation } from "@/lib/radio-stations";
import { getCurrentProgram, getCurrentDayKey } from "@/lib/programming-schedule";

export default function HomeScreen() {
  const router = useRouter();
  const { width: screenWidth, height: screenHeight } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const [selectedStation, setSelectedStation] = useState<RadioStation>(radioStations[0]);
  const [showStationsModal, setShowStationsModal] = useState(false);
  const { state, play, pause, updateLockScreenWithArtwork } = useRadioPlayer();
  const isPlaying = state.isPlaying && state.currentStationId === selectedStation.id;
  const { nowPlaying, coverUrl, isLoading, refresh: refreshNowPlaying } = useNowPlaying(selectedStation.statsUrl, isPlaying);
  const { liveProgram } = useLiveProgram();
  const { music: liveMusic, refetch: refetchLiveMusic } = useLiveMusicNow(isPlaying, selectedStation.streamUrl);
  const currentProgram = getCurrentProgram(getCurrentDayKey());
  const nowPlayingString = nowPlaying?.title ? `${nowPlaying.artist} - ${nowPlaying.title}` : "";
  const musicString = liveMusic || nowPlayingString;
  const { cover: musicCover } = useMusicCover(musicString, (_coverUrl) => {});

  const displayMusicTitle = liveMusic || nowPlayingString;
  const isLoadingMusic = isLoading && !displayMusicTitle;
  const displayImage = musicCover?.coverUrl || (liveProgram?.img && !liveProgram.img.includes("placeholder") ? liveProgram.img : null);

  useEffect(() => {
    if (isPlaying && liveProgram && !musicCover?.coverUrl) {
      const programImg = liveProgram.img && !liveProgram.img.includes("placeholder") ? liveProgram.img : "";
      console.log("[HomeScreen] Atualizando programa em background:", liveProgram.programa, "Imagem:", programImg);
      updateCurrentProgram(liveProgram.programa, programImg);
    }
  }, [liveProgram, isPlaying, musicCover?.coverUrl]);

  const handlePlayPause = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    if (isPlaying) {
      await pause();
    } else {
      await play(selectedStation.id, selectedStation.streamUrl, "Nossa Sertaneja");
    }
  };

  const PLAY_STORE_URL = "https://play.google.com/store/apps/details?id=com.nossasertaneja.app";

  const handleShare = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    const songInfo = liveMusic
      ? `\nOuvindo agora: ${liveMusic}`
      : currentProgram
      ? `\nPrograma: ${currentProgram.programa}`
      : "";
    try {
      await Share.share({
        message: `🎵 Estou ouvindo Nossa Sertaneja ao vivo!${songInfo}\n\nBaixe o app: ${PLAY_STORE_URL}`,
        title: "Nossa Sertaneja Rádio",
      });
    } catch (_) {}
  };

  const [vote, setVote] = useState<"like" | "dislike" | null>(null);
  const [toastMsg, setToastMsg] = useState("");
  const [toastVisible, setToastVisible] = useState(false);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lastSongKey = useRef<string>("");
  const lastProgramKey = useRef<string>("");
  const autoplayRef = useRef(false);


  const appStateRef = useRef<AppStateStatus>(AppState.currentState);
  useEffect(() => {
    const sub = AppState.addEventListener("change", (nextState) => {
      const wasBackground = appStateRef.current === "background" || appStateRef.current === "inactive";
      if (wasBackground && nextState === "active" && isPlaying) {
        refetchLiveMusic();
        refreshNowPlaying();
      }
      appStateRef.current = nextState;
    });
    return () => sub.remove();
  }, [isPlaying, refetchLiveMusic, refreshNowPlaying]);

  const prevIsPlayingRef = useRef(false);
  useEffect(() => {
    if (!prevIsPlayingRef.current && isPlaying) {
      setTimeout(() => { refetchLiveMusic(); refreshNowPlaying(); }, 1500);
    }
    prevIsPlayingRef.current = isPlaying;
  }, [isPlaying, refetchLiveMusic, refreshNowPlaying]);

  useEffect(() => {
    if (!autoplayRef.current && !isPlaying) {
      autoplayRef.current = true;
      // Pequeno delay para garantir que o TrackPlayer está inicializado
      setTimeout(() => {
        play(selectedStation.id, selectedStation.streamUrl, "Nossa Sertaneja");
      }, 500);
    }
  }, []);

  useEffect(() => {
    const key = liveMusic ?? "";
    if (key && key !== lastSongKey.current) {
      lastSongKey.current = key;
      setVote(null);
    }
  }, [liveMusic]);

  useEffect(() => {
    const programKey = currentProgram?.programa ?? "";
    if (programKey && programKey !== lastProgramKey.current) {
      lastProgramKey.current = programKey;
      setVote(null);
    }
  }, [currentProgram?.programa]);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setToastVisible(true);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToastVisible(false), 2500);
  };

  const handleVote = (type: "like" | "dislike") => {
    if (vote !== null) return;
    Haptics.notificationAsync(
      type === "like"
        ? Haptics.NotificationFeedbackType.Success
        : Haptics.NotificationFeedbackType.Warning
    );
    setVote(type);
    showToast(
      type === "like"
        ? "Obrigado pelo seu feedback! 🎵"
        : "Obrigado pelo seu feedback!"
    );
  };

  const usableWidth = screenWidth - 32;
  const usableHeight = screenHeight - insets.top - insets.bottom - 60;
  
  const isSmallScreen = screenWidth < 380;
  const isMediumScreen = screenWidth >= 380 && screenWidth < 480;
  
  const cardWidth = Math.min(usableWidth * 0.85, 360);
  const coverHeight = cardWidth * 1.1;
  
  let logoWidth: number;
  if (isSmallScreen) {
    logoWidth = Math.min(usableWidth * 0.8, 280);
  } else if (isMediumScreen) {
    logoWidth = Math.min(usableWidth * 0.7, 300);
  } else {
    logoWidth = Math.min(usableWidth * 0.6, 320);
  }
  const logoHeight = logoWidth * 0.8;
  
  const headerHeight = 60;
  const headerPadding = 8;
  const cardGap = Math.max(8, usableHeight * 0.02);
  const controlsGap = Math.max(12, usableWidth * 0.04);
  
  const likeDislikeSize = 60;
  const playButtonSize = Math.max(70, Math.min(90, usableWidth * 0.18));
  
  const programTitleFontSize = isSmallScreen ? 18 : isMediumScreen ? 22 : 22;
  const musicTitleFontSize = isSmallScreen ? 12 : isMediumScreen ? 14 : 14;

  return (
    <ScreenContainer edges={["top", "left", "right"]} className="bg-[#D07600]">
      {/* Header com Menu, Logo e Compartilhar */}
      <View 
        style={{ 
          height: headerHeight,
          paddingHorizontal: headerPadding,
          paddingVertical: 4,
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between",
          zIndex: 1,
          overflow: "visible",
          position: "relative"
        }}
      >
        <TouchableOpacity
          onPress={() => setShowStationsModal(true)}
          style={{ 
            padding: 10, 
            zIndex: 1100, 
            position: "absolute", 
            left: 8, 
            top: 10 
          }}
          hitSlop={{ top: 20, bottom: 20, left: 20, right: 20 }}
        >
          <Ionicons name="menu" size={32} color="#FFFFFF" />
        </TouchableOpacity>

        <Image
          source={require("@/assets/images/logo-transparent.png")}
          style={{ 
            width: logoWidth,
            height: logoHeight,
            position: "absolute",
            left: screenWidth / 2,
            marginLeft: -logoWidth / 2,
            top: headerHeight / 2 - logoHeight / 2 + 20,
            zIndex: 10,
          }}
          resizeMode="contain"
        />

        <TouchableOpacity
          onPress={handleShare}
          style={{ 
            padding: 10, 
            zIndex: 1100, 
            position: "absolute", 
            right: 8, 
            top: 10 
          }}
          hitSlop={{ top: 20, bottom: 20, left: 20, right: 20 }}
        >
          <Ionicons name="share-social" size={32} color="#FFFFFF" />
        </TouchableOpacity>
      </View>

      <ScrollView 
        contentContainerStyle={{ flexGrow: 1 }}
        scrollEnabled={false}
        style={{ flex: 1 }}
      >
        <View 
          style={{ 
            flex: 1,
            alignItems: "center",
            justifyContent: "center",
            paddingHorizontal: 16,
            gap: cardGap,
            paddingVertical: cardGap,
          }}
        >
          <View 
            style={{ 
              width: cardWidth,
              height: coverHeight,
              borderRadius: 24,
              overflow: "hidden",
              backgroundColor: "#FFFFFF",
              elevation: 12, 
              shadowColor: "#000", 
              shadowOffset: { width: 0, height: 8 }, 
              shadowOpacity: 0.5, 
              shadowRadius: 16,
              borderWidth: 4,
              borderColor: "rgba(255, 255, 255, 0.4)"
            }}
          >
            <View 
              style={{
                width: "100%",
                height: "100%",
                backgroundColor: "#2C3E50",
                alignItems: "center",
                justifyContent: "center"
              }}
            >
              {displayImage ? (
                <Image
                  source={{ uri: displayImage }}
                  style={{ 
                    width: "100%", 
                    height: "100%",
                    opacity: isPlaying ? 1 : 0.7
                  }}
                  resizeMode="cover"
                />
              ) : (
                <Image
                  source={require("@/assets/images/icon.png")}
                  style={{ 
                    width: coverHeight * 0.65, 
                    height: coverHeight * 0.65, 
                    opacity: 0.3 
                  }}
                  resizeMode="contain"
                />
              )}
            </View>
          </View>

          <View 
            style={{ 
              borderRadius: 20,
              paddingHorizontal: 16,
              paddingVertical: 12,
              alignItems: "center",
              justifyContent: "center",
              backgroundColor: "#D07600",
              width: "100%",
              maxWidth: cardWidth + 20,
              elevation: 8,
              shadowColor: "#000",
              shadowOffset: { width: 0, height: 4 },
              shadowOpacity: 0.3,
              shadowRadius: 8
            }}
          >
            <Text 
              numberOfLines={1}
              style={{ 
                color: "#FFFFFF",
                fontWeight: "700",
                fontSize: programTitleFontSize,
                textAlign: "center"
              }}
            >
              {currentProgram?.programa?.toUpperCase() || "OUÇA AO VIVO"}
            </Text>
            {displayMusicTitle && (
              <Text 
                numberOfLines={2}
                style={{ 
                  color: "#FFFFFF",
                  textAlign: "center",
                  marginTop: 6,
                  fontSize: musicTitleFontSize,
                  fontWeight: "500",
                  opacity: 0.9
                }}
              >
                {displayMusicTitle}
              </Text>
            )}
            {isLoadingMusic && (
              <Text 
                numberOfLines={1}
                style={{ 
                  color: "#FFFFFF",
                  textAlign: "center",
                  marginTop: 6,
                  fontSize: musicTitleFontSize,
                  opacity: 0.7,
                  fontWeight: "500"
                }}
              >
                Carregando...
              </Text>
            )}
          </View>

          <View 
            style={{ 
              flexDirection: "row",
              gap: controlsGap,
              justifyContent: "center",
              alignItems: "center",
              marginTop: cardGap
            }}
          >
            <TouchableOpacity
              onPress={() => handleVote("dislike")}
              style={{
                width: likeDislikeSize, 
                height: likeDislikeSize, 
                alignItems: "center", 
                justifyContent: "center",
                opacity: vote !== null && vote !== "dislike" ? 0.4 : 1
              }}
            >
              <Ionicons
                name={vote === "dislike" ? "thumbs-down" : "thumbs-down-outline"}
                size={likeDislikeSize * 0.45}
                color="#FFFFFF"
              />
            </TouchableOpacity>

            <TouchableOpacity
              onPress={handlePlayPause}
              style={{
                width: playButtonSize,
                height: playButtonSize,
                borderRadius: playButtonSize / 2,
                backgroundColor: "#FFFFFF",
                alignItems: "center",
                justifyContent: "center",
                elevation: 8,
                shadowColor: "#000",
                shadowOffset: { width: 0, height: 4 },
                shadowOpacity: 0.3,
                shadowRadius: 8
              }}
            >
              <Ionicons
                name={isPlaying ? "pause" : "play"}
                size={playButtonSize * 0.48}
                color="#D07600"
                style={{ marginLeft: isPlaying ? 0 : 3 }}
              />
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => handleVote("like")}
              style={{
                width: likeDislikeSize, 
                height: likeDislikeSize, 
                alignItems: "center", 
                justifyContent: "center",
                opacity: vote !== null && vote !== "like" ? 0.4 : 1
              }}
            >
              <Ionicons
                name={vote === "like" ? "thumbs-up" : "thumbs-up-outline"}
                size={likeDislikeSize * 0.45}
                color="#FFFFFF"
              />
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>

      {toastVisible && (
        <View 
          style={{
            position: "absolute",
            bottom: 90,
            left: 32,
            right: 32,
            backgroundColor: "rgba(0,0,0,0.85)",
            paddingVertical: 12,
            paddingHorizontal: 16,
            borderRadius: 12,
            alignItems: "center",
            justifyContent: "center",
            zIndex: 9999
          }}
        >
          <Text style={{ color: "#FFFFFF", fontSize: 14, fontWeight: "600", textAlign: "center" }}>
            {toastMsg}
          </Text>
        </View>
      )}

      {/* Drawer Compartilhado */}
      <RadioDrawer
        visible={showStationsModal}
        onClose={() => setShowStationsModal(false)}
      />
    </ScreenContainer>
  );
}
