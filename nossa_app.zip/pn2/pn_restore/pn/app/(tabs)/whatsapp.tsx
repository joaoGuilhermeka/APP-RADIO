import { useEffect, useRef } from "react";
import { View, Text, Linking, Platform } from "react-native";
import { router, useFocusEffect } from "expo-router";
import { useCallback } from "react";
import { Ionicons } from "@expo/vector-icons";

export default function WhatsAppScreen() {
  const hasOpened = useRef(false);

  useFocusEffect(
    useCallback(() => {
      // Toda vez que a aba recebe foco, abre o WhatsApp
      const openWhatsApp = async () => {
        const phoneNumber = "558003663232"; // +55 800 366 3232
        const message = "Olá! Entrei em contato através do aplicativo Nossa Sertaneja.";

        const whatsappURL = Platform.select({
          ios: `whatsapp://send?phone=${phoneNumber}&text=${encodeURIComponent(message)}`,
          android: `whatsapp://send?phone=${phoneNumber}&text=${encodeURIComponent(message)}`,
          web: `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`,
        });

        try {
          const canOpen = await Linking.canOpenURL(whatsappURL!);
          if (canOpen) {
            await Linking.openURL(whatsappURL!);
          } else {
            const webURL = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;
            await Linking.openURL(webURL);
          }
        } catch (error) {
          console.error("Erro ao abrir WhatsApp:", error);
        } finally {
          // Volta para a tela inicial após abrir o WhatsApp
          setTimeout(() => {
            router.replace("/");
          }, 300);
        }
      };

      openWhatsApp();
    }, [])
  );

  // Tela de loading enquanto redireciona
  return (
    <View
      style={{
        flex: 1,
        backgroundColor: "#D07600",
        alignItems: "center",
        justifyContent: "center",
        gap: 16,
      }}
    >
      <View
        style={{
          width: 80,
          height: 80,
          borderRadius: 40,
          backgroundColor: "#25D366",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Ionicons name="logo-whatsapp" size={48} color="#FFFFFF" />
      </View>
      <Text
        style={{
          color: "#FFFFFF",
          fontSize: 18,
          fontWeight: "bold",
          textAlign: "center",
        }}
      >
        Abrindo WhatsApp...
      </Text>
      <Text
        style={{
          color: "rgba(255,255,255,0.8)",
          fontSize: 14,
          textAlign: "center",
          paddingHorizontal: 32,
        }}
      >
        Você será redirecionado para conversar com nossa equipe
      </Text>
    </View>
  );
}
