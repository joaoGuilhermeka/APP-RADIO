import {
  ScrollView, Text, View, TextInput, Pressable,
  Linking, Platform, FlatList, ActivityIndicator,
  TouchableOpacity, Keyboard, Image, Share, Dimensions,
} from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { RadioDrawer } from "@/components/radio-drawer";
import { useState, useRef, useCallback } from "react";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";

const { width: SCREEN_WIDTH } = Dimensions.get("window");
const WHATSAPP_NUMBER = "558003663232";

interface ItunesTrack {
  trackId: number;
  trackName: string;
  artistName: string;
  artworkUrl60: string;
  collectionName?: string;
}

export default function MusicScreen() {
  const router = useRouter();
  const { width: screenWidth } = Dimensions.get("window");

  const [listenerName, setListenerName] = useState("");
  const [city, setCity] = useState("");
  const [artistName, setArtistName] = useState("");
  const [musicName, setMusicName] = useState("");
  const [sending, setSending] = useState(false);
  const [showStationsModal, setShowStationsModal] = useState(false);

  const [searchResults, setSearchResults] = useState<ItunesTrack[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const searchTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);

  const isFormValid = listenerName.trim() && city.trim() && musicName.trim();

  const isSmallScreen = SCREEN_WIDTH < 380;
  const isMediumScreen = SCREEN_WIDTH >= 380 && SCREEN_WIDTH < 480;
  const usableWidth = SCREEN_WIDTH - 32;

  let logoWidth: number;
  if (isSmallScreen) {
    logoWidth = Math.min(usableWidth * 0.8, 280);
  } else if (isMediumScreen) {
    logoWidth = Math.min(usableWidth * 0.7, 300);
  } else {
    logoWidth = Math.min(usableWidth * 0.6, 320);
  }
  const logoHeight = logoWidth * 0.8;
  const headerHeight = 60;
  const headerPadding = 8;

  const handleShare = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    try {
      await Share.share({
        message: `Estou pedindo música na Nossa Sertaneja 🎵`,
        title: "Nossa Sertaneja Rádio",
      });
    } catch (_) {}
  };

  const handleSearchChange = useCallback((text: string) => {
    setMusicName(text);
    setArtistName("");
    setShowResults(false);

    if (searchTimeout.current) clearTimeout(searchTimeout.current);

    if (text.trim().length < 2) {
      setSearchResults([]);
      return;
    }

    searchTimeout.current = setTimeout(async () => {
      setIsSearching(true);
      try {
        const encoded = encodeURIComponent(text.trim());
        const url = `https://itunes.apple.com/search?term=${encoded}&media=music&entity=song&country=br&limit=6&lang=pt_br`;
        const res = await fetch(url);
        const data = await res.json();
        setSearchResults(data.results ?? []);
        setShowResults((data.results ?? []).length > 0);
      } catch {
        setSearchResults([]);
      } finally {
        setIsSearching(false);
      }
    }, 500);
  }, []);

  const handleSelectTrack = (track: ItunesTrack) => {
    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setArtistName(track.artistName);
    setMusicName(track.trackName);
    setSearchResults([]);
    setShowResults(false);
    Keyboard.dismiss();
  };

  const handleSubmit = async () => {
    if (!isFormValid) return;
    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    setSending(true);
    const cityText = city.trim() ? `\n📍 Cidade: ${city.trim()}` : "";
    const artistText = artistName.trim() ? `\n🎤 Artista: ${artistName.trim()}` : "";
    const message =
      `🎵 *Pedido de Música - Nossa Sertaneja*\n\n` +
      `👤 Nome: ${listenerName.trim()}` +
      cityText +
      artistText +
      `\n🎶 Música: ${musicName.trim()}`;

    const encodedMessage = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodedMessage}`;

    try {
      const supported = await Linking.canOpenURL(whatsappUrl);
      if (supported) {
        await Linking.openURL(whatsappUrl);
      } else {
        alert("Não foi possível abrir o WhatsApp.");
      }
    } catch {
      alert("Erro ao tentar enviar o pedido.");
    } finally {
      setSending(false);
    }
  };

  return (
    <ScreenContainer edges={["top", "left", "right"]} className="bg-[#D07600]">
      {/* Header com Menu, Logo e Compartilhar */}
      <View
        style={{
          height: headerHeight,
          paddingHorizontal: headerPadding,
          paddingVertical: 4,
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between",
          zIndex: 1,
          overflow: "visible",
          position: "relative",
        }}
      >
        <TouchableOpacity
          onPress={() => setShowStationsModal(true)}
          style={{
            padding: 10,
            zIndex: 1100,
            position: "absolute",
            left: 8,
            top: 10,
          }}
          hitSlop={{ top: 20, bottom: 20, left: 20, right: 20 }}
        >
          <Ionicons name="menu" size={32} color="#FFFFFF" />
        </TouchableOpacity>

        <Image
          source={require("@/assets/images/logo-transparent.png")}
          style={{
            width: logoWidth,
            height: logoHeight,
            position: "absolute",
            left: screenWidth / 2,
            marginLeft: -logoWidth / 2,
            top: headerHeight / 2 - logoHeight / 2 + 20,
            zIndex: 10,
          }}
          resizeMode="contain"
        />

        <TouchableOpacity
          onPress={handleShare}
          style={{
            padding: 10,
            zIndex: 1100,
            position: "absolute",
            right: 8,
            top: 10,
          }}
          hitSlop={{ top: 20, bottom: 20, left: 20, right: 20 }}
        >
          <Ionicons name="share-social" size={32} color="#FFFFFF" />
        </TouchableOpacity>
      </View>

      <ScrollView
        contentContainerStyle={{ padding: 16, paddingBottom: 130, paddingTop: 55, justifyContent: "center", flexGrow: 1 }}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <View style={{ alignItems: "center", marginBottom: 28, marginTop: 10 }}>
          <Text style={{ fontSize: 28, fontWeight: "900", color: "#FFFFFF", textAlign: "center" }}>
            Peça sua Música
          </Text>
        </View>

        {/* Formulário */}
        <View
          style={{
            backgroundColor: "#FFFFFF",
            borderRadius: 20,
            padding: 20,
            shadowColor: "#000",
            shadowOffset: { width: 0, height: 4 },
            shadowOpacity: 0.2,
            shadowRadius: 10,
            elevation: 8,
          }}
        >
          {/* Nome */}
          <View style={{ marginBottom: 16 }}>
            <Text style={{ fontSize: 13, fontWeight: "700", color: "#333", marginBottom: 6 }}>
              Seu Nome *
            </Text>
            <TextInput
              value={listenerName}
              onChangeText={setListenerName}
              placeholder="Digite seu nome"
              placeholderTextColor="#999"
              style={{
                backgroundColor: "#F9FAFB",
                borderWidth: 1,
                borderColor: "#E5E7EB",
                borderRadius: 10,
                paddingHorizontal: 14,
                paddingVertical: 12,
                fontSize: 15,
                color: "#111",
              }}
            />
          </View>

          {/* Cidade */}
          <View style={{ marginBottom: 16 }}>
            <Text style={{ fontSize: 13, fontWeight: "700", color: "#333", marginBottom: 6 }}>
              Sua Cidade *
            </Text>
            <TextInput
              value={city}
              onChangeText={setCity}
              placeholder="Ex: Barbacena - MG"
              placeholderTextColor="#999"
              style={{
                backgroundColor: "#F9FAFB",
                borderWidth: 1,
                borderColor: "#E5E7EB",
                borderRadius: 10,
                paddingHorizontal: 14,
                paddingVertical: 12,
                fontSize: 15,
                color: "#111",
              }}
            />
          </View>

          {/* Música / Artista */}
          <View style={{ marginBottom: 20 }}>
            <Text style={{ fontSize: 13, fontWeight: "700", color: "#333", marginBottom: 6 }}>
              Nome da Música ou Artista *
            </Text>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                backgroundColor: "#F9FAFB",
                borderWidth: 1,
                borderColor: "#E5E7EB",
                borderRadius: 10,
                paddingHorizontal: 12,
              }}
            >
              <TextInput
                value={musicName}
                onChangeText={handleSearchChange}
                placeholder="Busque a música..."
                placeholderTextColor="#999"
                returnKeyType="done"
                style={{ flex: 1, paddingVertical: 12, fontSize: 15, color: "#111" }}
              />
              {isSearching && <ActivityIndicator size="small" color="#D07600" style={{ marginRight: 6 }} />}
              {musicName.length > 0 && !isSearching && (
                <TouchableOpacity
                  onPress={() => {
                    setMusicName("");
                    setArtistName("");
                    setSearchResults([]);
                    setShowResults(false);
                  }}
                  style={{ padding: 4 }}
                >
                  <Ionicons name="close-circle" size={20} color="#888" />
                </TouchableOpacity>
              )}
            </View>

            {/* Sugestões do iTunes */}
            {showResults && searchResults.length > 0 && (
              <View
                style={{
                  marginTop: 6,
                  backgroundColor: "#F3F4F6",
                  borderRadius: 10,
                  borderWidth: 1,
                  borderColor: "#E5E7EB",
                  maxHeight: 180,
                  overflow: "hidden",
                }}
              >
                <FlatList
                  data={searchResults}
                  keyExtractor={(item) => item.trackId.toString()}
                  keyboardShouldPersistTaps="handled"
                  scrollEnabled={false}
                  renderItem={({ item }) => (
                    <TouchableOpacity
                      onPress={() => handleSelectTrack(item)}
                      style={{
                        paddingVertical: 10,
                        paddingHorizontal: 12,
                        borderBottomWidth: 1,
                        borderBottomColor: "#E5E7EB",
                        backgroundColor: "#FFFFFF",
                      }}
                    >
                      <Text style={{ fontSize: 14, fontWeight: "700", color: "#1F2937" }} numberOfLines={1}>
                        {item.trackName}
                      </Text>
                      <Text style={{ fontSize: 12, color: "#6B7280", marginTop: 2 }} numberOfLines={1}>
                        {item.artistName}
                      </Text>
                    </TouchableOpacity>
                  )}
                />
              </View>
            )}

            {artistName ? (
              <Text style={{ fontSize: 12, color: "#D07600", fontWeight: "600", marginTop: 6 }}>
                Selecionado: {artistName}
              </Text>
            ) : null}
          </View>

          {/* Botão Enviar */}
          <Pressable
            onPress={handleSubmit}
            disabled={!isFormValid || sending}
            style={({ pressed }) => [
              {
                backgroundColor: isFormValid ? "#D07600" : "#D1D5DB",
                borderRadius: 12,
                paddingVertical: 14,
                alignItems: "center",
                justifyContent: "center",
                flexDirection: "row",
                gap: 8,
              },
              pressed && isFormValid && { transform: [{ scale: 0.98 }], opacity: 0.9 },
            ]}
          >
            <Ionicons name="logo-whatsapp" size={20} color="#FFFFFF" />
            <Text style={{ color: "#FFFFFF", fontSize: 15, fontWeight: "700" }}>
              {sending ? "Abrindo WhatsApp..." : "Enviar Pedido via WhatsApp"}
            </Text>
          </Pressable>
        </View>
      </ScrollView>

      {/* Mini Player Sincronizado para Páginas Secundárias */}

      {/* Drawer Compartilhado */}
      <RadioDrawer
        visible={showStationsModal}
        onClose={() => setShowStationsModal(false)}
      />
    </ScreenContainer>
  );
}
