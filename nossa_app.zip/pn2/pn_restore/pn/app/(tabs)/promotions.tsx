import { ScrollView, Text, View, Image, Pressable } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";

interface Promotion {
  id: string;
  title: string;
  description: string;
  station: string;
  date: string;
  icon: string;
}

const PROMOTIONS: Promotion[] = [
  {
    id: "1",
    title: "Sorteio de Ingressos",
    description: "Concorra a ingressos para o festival de música sertaneja",
    station: "BARBACENA 99.7 FM",
    date: "Até 28 de Fevereiro",
    icon: "card-giftcard",
  },
  {
    id: "2",
    title: "Hora da Gravata",
    description: "Participe e ganhe prêmios incríveis",
    station: "PRADÓPOLIS 88.5 FM",
    date: "Todos os dias às 18h",
    icon: "star",
  },
  {
    id: "3",
    title: "Cupom de Desconto",
    description: "Ganhe 20% de desconto em lojas parceiras",
    station: "PARACATU 97.3 FM",
    date: "Válido até 31 de Março",
    icon: "local-offer",
  },
  {
    id: "4",
    title: "Playlist Exclusiva",
    description: "Ouça as melhores músicas sertanejas do momento",
    station: "BUENO BRANDÃO 102.5 FM",
    date: "Disponível agora",
    icon: "album",
  },
];

export default function PromotionsScreen() {
  return (
    <ScreenContainer className="bg-background">
      <ScrollView
        contentContainerStyle={{ flexGrow: 1, paddingBottom: 20 }}
        showsVerticalScrollIndicator={false}
      >
        <View className="gap-4 px-4 pt-6">
          {/* Header */}
          <View className="items-center gap-2 mb-2">
            <MaterialIcons name="celebration" size={48} color="#D07600" />
            <Text className="text-3xl font-bold text-foreground">
              Promoções
            </Text>
            <Text className="text-sm text-muted text-center">
              Confira as promoções e sorteios das nossas estações
            </Text>
          </View>

          {/* Promotions List */}
          <View className="gap-3">
            {PROMOTIONS.map((promo) => (
              <Pressable
                key={promo.id}
                style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
              >
                <View className="bg-surface rounded-xl border border-border overflow-hidden">
                  {/* Header */}
                  <View className="bg-primary/10 flex-row items-center gap-3 p-4">
                    <View className="w-12 h-12 rounded-full bg-primary items-center justify-center">
                      <MaterialIcons
                        name={promo.icon as any}
                        size={24}
                        color="white"
                      />
                    </View>
                    <View className="flex-1">
                      <Text className="font-bold text-foreground text-base">
                        {promo.title}
                      </Text>
                      <Text className="text-xs text-muted mt-1">
                        {promo.station}
                      </Text>
                    </View>
                  </View>

                  {/* Content */}
                  <View className="p-4 gap-3">
                    <Text className="text-sm text-foreground leading-relaxed">
                      {promo.description}
                    </Text>

                    {/* Date */}
                    <View className="flex-row items-center gap-2 pt-2 border-t border-border">
                      <MaterialIcons
                        name="access-time"
                        size={16}
                        color="#D07600"
                      />
                      <Text className="text-xs text-muted">{promo.date}</Text>
                    </View>

                    {/* Action Button */}
                    <Pressable
                      style={({ pressed }) => [
                        {
                          opacity: pressed ? 0.8 : 1,
                        },
                      ]}
                    >
                      <View className="bg-primary/10 rounded-lg py-2 items-center mt-2">
                        <Text className="text-sm font-semibold text-primary">
                          Saiba Mais
                        </Text>
                      </View>
                    </Pressable>
                  </View>
                </View>
              </Pressable>
            ))}
          </View>

          {/* Info Banner */}
          <View className="bg-primary/10 rounded-lg p-4 gap-2 mt-4">
            <View className="flex-row items-start gap-2">
              <MaterialIcons name="info" size={20} color="#D07600" />
              <Text className="text-sm text-foreground flex-1">
                Acompanhe nossas rádios para não perder nenhuma promoção!
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
