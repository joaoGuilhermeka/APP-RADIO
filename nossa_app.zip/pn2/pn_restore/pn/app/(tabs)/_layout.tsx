import { Tabs } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { HapticTab } from "@/components/haptic-tab";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { Ionicons } from "@expo/vector-icons";
import { Platform, View } from "react-native";
import { useColors } from "@/hooks/use-colors";
import { SecondaryMiniPlayer } from "@/components/secondary-mini-player";
import { useRadioPlayer } from "@/hooks/use-radio-player";
import { usePathname } from "expo-router";


export default function TabLayout() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const bottomPadding = Platform.OS === "web" ? 12 : Math.max(insets.bottom, 8);
  const tabBarHeight = 70 + bottomPadding;
  const { state } = useRadioPlayer();
  const pathname = usePathname();
  // Mostrar mini player em todas as telas EXCETO home (/)
  const showMiniPlayer = pathname !== "/";

  return (
    <View style={{ flex: 1 }}>
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: "#D07600",
        tabBarInactiveTintColor: "#999999",
        headerShown: false,
        tabBarButton: HapticTab,
        sceneStyle: {
          backgroundColor: "transparent",
        },
        tabBarActiveTintColor: "#000000",
        tabBarInactiveTintColor: "#FFFFFF",
        tabBarBackground: () => (
          <View
            style={{
              flex: 1,
              backgroundColor: "#D07600",
              borderTopWidth: 1,
              borderTopColor: "rgba(255, 255, 255, 0.25)",
              shadowColor: "#000",
              shadowOffset: { width: 0, height: -6 },
              shadowOpacity: 0.4,
              shadowRadius: 10,
              elevation: 16,
            }}
          />
        ),
        tabBarStyle: {
          paddingTop: 12,
          paddingBottom: bottomPadding,
          height: tabBarHeight,
          backgroundColor: "#D07600",
          borderTopWidth: 0,
          elevation: 16,
          shadowColor: "#000",
          shadowOffset: { width: 0, height: -6 },
          shadowOpacity: 0.4,
          shadowRadius: 10,
        },
        tabBarLabelStyle: {
          fontSize: 10,
          fontWeight: "700",
        },
      }}
    >
      {/* 1. Home */}
      <Tabs.Screen
        name="index"
        options={{
          title: "Início",
          tabBarIcon: ({ color }) => <IconSymbol size={32} name="house.fill" color={color} />,
        }}
      />
      {/* 2. TV */}
      <Tabs.Screen
        name="tv"
        options={{
          title: "Nossa TV",
          tabBarIcon: ({ color }) => <IconSymbol size={32} name="tv" color={color} />,
        }}
      />
      {/* 3. Pedidos */}
      <Tabs.Screen
        name="music"
        options={{
          title: "Pedidos",
          tabBarIcon: ({ color }) => <IconSymbol size={32} name="music.note" color={color} />,
        }}
      />
      {/* 4. WhatsApp */}
      <Tabs.Screen
        name="whatsapp"
        options={{
          title: "WhatsApp",
          tabBarIcon: ({ color, focused }) => (
            <Ionicons name="logo-whatsapp" size={26} color={focused ? "#000000" : "#FFFFFF"} />
          ),
        }}
      />
      {/* Ocultar aba promotions da barra */}
      <Tabs.Screen
        name="promotions"
        options={{
          href: null,
        }}
      />
      {/* 5. Programação */}
      <Tabs.Screen
        name="news"
        options={{
          title: "Programação",
          tabBarIcon: ({ color }) => <IconSymbol size={32} name="newspaper" color={color} />,
        }}
      />
    </Tabs>
      {showMiniPlayer && <SecondaryMiniPlayer />}
    </View>
  );
}
