import { View, Text, ScrollView, Image, Pressable } from "react-native";
import { useState } from "react";
import { Ionicons } from "@expo/vector-icons";
import { ScreenContainer } from "@/components/screen-container";
import { programacaoSemanal, dayLabels, getCurrentDayKey, type DayKey, type Program } from "@/lib/programming-schedule";
import { useLiveProgram } from "@/hooks/use-live-program";
import * as Haptics from "expo-haptics";
import { Platform, Dimensions } from "react-native";

export default function ProgrammingScreen() {
  const { currentDay, liveProgram } = useLiveProgram();
  const [selectedDay, setSelectedDay] = useState<DayKey>(getCurrentDayKey());
  const screenWidth = Dimensions.get("window").width;
  const isLargeScreen = screenWidth > 600;
  const imageSize = isLargeScreen ? 120 : 90;
  const cardMinHeight = isLargeScreen ? 110 : 90;

  // Verificar se um programa está ao vivo agora
  const isLiveNow = (program: Program): boolean => {
    if (selectedDay !== currentDay) return false;
    return liveProgram?.inicio === program.inicio && liveProgram?.programa === program.programa;
  };

  const handleDaySelect = (day: DayKey) => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    setSelectedDay(day);
  };

  const programs: Program[] = programacaoSemanal[selectedDay] ?? [];

  return (
    <ScreenContainer containerClassName="bg-[#D07600]">
      {/* Header */}
      <View style={{ paddingHorizontal: 16, paddingTop: 20, paddingBottom: 12, alignItems: "center" }}>
        <Text style={{ fontSize: 26, fontWeight: "800", color: "#FFFFFF", letterSpacing: 1 }}>
          PROGRAMAÇÃO
        </Text>
      </View>

      {/* Seletor de Dias - Horizontal Deslizável */}
      <View style={{ paddingBottom: 12 }}>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: 16, gap: 10 }}
        >
          {dayLabels.map(({ key, label }) => {
            const isSelected = selectedDay === key;
            const isToday = currentDay === key;
            return (
              <Pressable
                key={key}
                onPress={() => handleDaySelect(key)}
                style={({ pressed }) => ({
                  paddingHorizontal: 20,
                  paddingVertical: 11,
                  backgroundColor: isSelected
                    ? "#FFFFFF"
                    : pressed
                    ? "rgba(255,255,255,0.5)"
                    : "rgba(255,255,255,0.25)",
                  borderRadius: 14,
                  minWidth: 75,
                  alignItems: "center",
                  justifyContent: "center",
                  borderWidth: isToday ? 2 : 0,
                  borderColor: "#FFFFFF",
                  shadowColor: "#000",
                  shadowOffset: { width: 0, height: 2 },
                  shadowOpacity: isSelected ? 0.2 : 0,
                  shadowRadius: 4,
                  elevation: isSelected ? 4 : 0,
                })}
              >
                {({ pressed }) => (
                  <Text
                    style={{
                      fontWeight: "800",
                      fontSize: 14,
                      color: isSelected ? "#D07600" : "#FFFFFF",
                    }}
                  >
                    {label}
                  </Text>
                )}
              </Pressable>
            );
          })}
        </ScrollView>
      </View>

      {/* Lista de Programas */}
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingHorizontal: isLargeScreen ? 24 : 16, paddingBottom: 110 }}
        showsVerticalScrollIndicator={false}
      >
        {programs.map((program: Program, index: number) => (
          <View
            key={`${program.inicio}-${index}`}
            style={{
              backgroundColor: "#FFFFFF",
              borderRadius: 14,
              marginBottom: 4,
              marginRight: 0,
              flexDirection: "row",
              alignItems: "stretch",
              height: imageSize,
              overflow: "hidden",
              shadowColor: "#000",
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.15,
              shadowRadius: 4,
              elevation: 3,
              borderWidth: 1,
              borderColor: "#e0e0e0",
            }}
          >
            {/* Imagem do Programa */}
            <View style={{ width: imageSize, height: imageSize, backgroundColor: "#e0e0e0", flexShrink: 0, overflow: "hidden", borderRadius: 14 }}>
              {program.img && program.img.startsWith("http") ? (
                <Image
                  source={{ uri: program.img }}
                  style={{ width: "100%", height: "100%" }}
                  resizeMode="cover"
                />
              ) : (
                <View style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: "#d0d0d0" }}>
                  <Ionicons name="radio" size={30} color="#999" />
                </View>
              )}
            </View>

            {/* Informações do Programa */}
            <View style={{ flex: 1, paddingHorizontal: isLargeScreen ? 16 : 12, paddingVertical: 10, justifyContent: "center" }}>
              {/* Badge AO VIVO */}
              {isLiveNow(program) && (
                <View style={{
                  flexDirection: "row",
                  alignItems: "center",
                  backgroundColor: "#e53935",
                  borderRadius: 6,
                  paddingHorizontal: 7,
                  paddingVertical: 2,
                  alignSelf: "flex-start",
                  marginBottom: 5,
                  marginRight: 8,
                  gap: 4,
                }}>
                  <View style={{ width: 6, height: 6, borderRadius: 3, backgroundColor: "#fff" }} />
                  <Text style={{ color: "#fff", fontSize: 10, fontWeight: "800", letterSpacing: 0.8 }}>AO VIVO</Text>
                </View>
              )}
              <Text style={{ fontSize: isLargeScreen ? 16 : 15, fontWeight: "700", color: "#222", marginBottom: 3 }} numberOfLines={1}>
                {program.programa || "Programação Musical"}
              </Text>
              {program.locutor ? (
                <Text style={{ fontSize: isLargeScreen ? 13 : 12, color: "#777" }} numberOfLines={1}>
                  {program.locutor}
                </Text>
              ) : null}
            </View>

            {/* Horário com ícone de relógio branco sobre fundo laranja */}
            <View
              style={{
                backgroundColor: "#D07600",
                paddingHorizontal: isLargeScreen ? 14 : 10,
                paddingVertical: 10,
                alignItems: "center",
                justifyContent: "center",
                minWidth: isLargeScreen ? 90 : 72,
                flexShrink: 0,
              }}
            >
              <Ionicons name="time" size={isLargeScreen ? 22 : 20} color="#FFFFFF" />
              <Text style={{ color: "#FFFFFF", fontSize: isLargeScreen ? 12 : 11, fontWeight: "700", marginTop: 4, textAlign: "center" }}>
                {program.inicio}
              </Text>
              <Text style={{ color: "#fff8", fontSize: 10, marginTop: 1 }}>—</Text>
              <Text style={{ color: "#FFFFFF", fontSize: isLargeScreen ? 12 : 11, fontWeight: "700", textAlign: "center" }}>
                {program.fim === "00:00" ? "00:00" : program.fim}
              </Text>
            </View>
          </View>
        ))}
      </ScrollView>

      {/* Mini Player Sincronizado para Páginas Secundárias */}
    </ScreenContainer>
  );
}
