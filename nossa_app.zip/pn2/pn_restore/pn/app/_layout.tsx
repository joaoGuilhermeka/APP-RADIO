import "@/global.css";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { useCallback, useEffect, useMemo, useState } from "react";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import "react-native-reanimated";
import { Platform, AppState, type AppStateStatus, NativeModules } from "react-native";
import "@/lib/_core/nativewind-pressable";
import { ThemeProvider } from "@/lib/theme-provider";
import {
  SafeAreaFrameContext,
  SafeAreaInsetsContext,
  SafeAreaProvider,
  initialWindowMetrics,
} from "react-native-safe-area-context";
import type { EdgeInsets, Metrics, Rect } from "react-native-safe-area-context";

import { trpc, createTRPCClient } from "@/lib/trpc";
import { initManusRuntime, subscribeSafeAreaInsets } from "@/lib/_core/manus-runtime";
import { CustomSplash } from "@/components/custom-splash";

const DEFAULT_WEB_INSETS: EdgeInsets = { top: 0, right: 0, bottom: 0, left: 0 };
const DEFAULT_WEB_FRAME: Rect = { x: 0, y: 0, width: 0, height: 0 };

export const unstable_settings = {
  anchor: "(tabs)",
};

export default function RootLayout() {
  const initialInsets = initialWindowMetrics?.insets ?? DEFAULT_WEB_INSETS;
  const initialFrame = initialWindowMetrics?.frame ?? DEFAULT_WEB_FRAME;

  const [insets, setInsets] = useState<EdgeInsets>(initialInsets);
  const [frame, setFrame] = useState<Rect>(initialFrame);
  // Splash screen: mostrar apenas no mobile (não no web)
  const [showSplash, setShowSplash] = useState(Platform.OS !== "web");

  // Initialize Manus runtime for cookie injection from parent container
  useEffect(() => {
    initManusRuntime();
  }, []);

  /**
   * CRÍTICO: Destruir notificação quando app é fechado
   * Executa cleanup agressivo quando app sai de foreground
   */
  useEffect(() => {
    if (Platform.OS !== "android") return;

    const handleAppStateChange = (nextAppState: AppStateStatus) => {
      console.log("[RootLayout] AppState:", nextAppState);

      // App foi removido da multitarefa ou encerrado
      if (nextAppState === "unknown" || nextAppState === "background") {
        console.log("[RootLayout] 🛑 App sendo fechado - destruindo notificação");

        try {
          // Tentar cancelar notificações via NativeModules
          if (NativeModules.NotificationManager) {
            NativeModules.NotificationManager.cancelAllNotifications();
            console.log("[RootLayout] ✓ Notificação cancelada via NativeModules");
          }
        } catch (error) {
          console.log("[RootLayout] ⚠️ NativeModules.NotificationManager não disponível");
        }

        // Fallback: Tentar via expo-notifications
        try {
          const notificationsModule = require("expo-notifications");
          if (notificationsModule && notificationsModule.dismissAllNotificationsAsync) {
            notificationsModule.dismissAllNotificationsAsync();
            console.log("[RootLayout] ✓ Notificação cancelada via expo-notifications");
          }
        } catch (error) {
          console.log("[RootLayout] ⚠️ expo-notifications não disponível");
        }
      }
    };

    const subscription = AppState.addEventListener("change", handleAppStateChange);

    return () => {
      subscription.remove();
    };
  }, []);

  /**
   * Cleanup final quando RootLayout é desmontado (app sendo destruído)
   */
  useEffect(() => {
    return () => {
      console.log("[RootLayout] 🛑 RootLayout desmontando - app sendo fechado");

      if (Platform.OS === "android") {
        try {
          if (NativeModules.NotificationManager) {
            NativeModules.NotificationManager.cancelAllNotifications();
            console.log("[RootLayout] ✓ Notificação cancelada no cleanup final");
          }
        } catch (error) {
          console.log("[RootLayout] ⚠️ Erro ao cancelar notificação no cleanup final");
        }

        try {
          const notificationsModule = require("expo-notifications");
          if (notificationsModule && notificationsModule.dismissAllNotificationsAsync) {
            notificationsModule.dismissAllNotificationsAsync();
          }
        } catch (error) {
          console.log("[RootLayout] ⚠️ Erro ao usar expo-notifications no cleanup final");
        }
      }
    };
  }, []);

  const handleSafeAreaUpdate = useCallback((metrics: Metrics) => {
    setInsets(metrics.insets);
    setFrame(metrics.frame);
  }, []);

  useEffect(() => {
    if (Platform.OS !== "web") return;
    const unsubscribe = subscribeSafeAreaInsets(handleSafeAreaUpdate);
    return () => unsubscribe();
  }, [handleSafeAreaUpdate]);

  // Create clients once and reuse them
  const [queryClient] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            // Disable automatic refetching on window focus for mobile
            refetchOnWindowFocus: false,
            // Retry failed requests once
            retry: 1,
          },
        },
      }),
  );
  const [trpcClient] = useState(() => createTRPCClient());

  // Ensure minimum 8px padding for top and bottom on mobile
  const providerInitialMetrics = useMemo(() => {
    const metrics = initialWindowMetrics ?? { insets: initialInsets, frame: initialFrame };
    return {
      ...metrics,
      insets: {
        ...metrics.insets,
        top: Math.max(metrics.insets.top, 16),
        bottom: Math.max(metrics.insets.bottom, 12),
      },
    };
  }, [initialInsets, initialFrame]);

  const content = (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <trpc.Provider client={trpcClient} queryClient={queryClient}>
        <QueryClientProvider client={queryClient}>
          <Stack screenOptions={{ headerShown: false }}>
            <Stack.Screen name="(tabs)" />
            <Stack.Screen name="oauth/callback" />
            <Stack.Screen name="+not-found" />
          </Stack>
          <StatusBar style="light" backgroundColor="#D07600" />
        </QueryClientProvider>
      </trpc.Provider>
      {showSplash && <CustomSplash onFinish={() => setShowSplash(false)} />}
    </GestureHandlerRootView>
  );

  const shouldOverrideSafeArea = Platform.OS === "web";

  if (shouldOverrideSafeArea) {
    return (
      <ThemeProvider>
        <SafeAreaProvider initialMetrics={providerInitialMetrics}>
          <SafeAreaFrameContext.Provider value={frame}>
            <SafeAreaInsetsContext.Provider value={insets}>
              {content}
            </SafeAreaInsetsContext.Provider>
          </SafeAreaFrameContext.Provider>
        </SafeAreaProvider>
      </ThemeProvider>
    );
  }

  return (
    <ThemeProvider>
      <SafeAreaProvider initialMetrics={providerInitialMetrics}>{content}</SafeAreaProvider>
    </ThemeProvider>
  );
}
