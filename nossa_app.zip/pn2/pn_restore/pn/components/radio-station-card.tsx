import { Pressable, Text, View } from "react-native";
import { RadioStation } from "@/lib/radio-stations";
import { cn } from "@/lib/utils";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";

interface RadioStationCardProps {
  station: RadioStation;
  isPlaying: boolean;
  isLoading: boolean;
  onPress: () => void;
}

export function RadioStationCard({
  station,
  isPlaying,
  isLoading,
  onPress,
}: RadioStationCardProps) {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        {
          opacity: pressed ? 0.7 : 1,
        },
      ]}
      className="mb-3"
    >
      <View
        className={cn(
          "flex-row items-center justify-between rounded-xl p-4 border",
          isPlaying ? "bg-primary/10 border-primary" : "bg-surface border-border"
        )}
      >
        <View className="flex-1">
          <Text className="text-lg font-semibold text-foreground">
            {station.name}
          </Text>
          <Text className="text-sm text-muted mt-1">Ao vivo</Text>
        </View>

        <View className="ml-4 items-center justify-center w-12 h-12">
          {isLoading ? (
            <MaterialIcons name="hourglass-empty" size={28} color="#FF8C00" />
          ) : isPlaying ? (
            <View className="items-center justify-center">
              <MaterialIcons name="pause-circle-filled" size={32} color="#FF8C00" />
              <View className="absolute w-10 h-10 rounded-full border-2 border-primary animate-pulse" />
            </View>
          ) : (
            <MaterialIcons name="play-circle-filled" size={32} color="#687076" />
          )}
        </View>
      </View>
    </Pressable>
  );
}
