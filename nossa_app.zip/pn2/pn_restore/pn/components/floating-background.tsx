import { View, Image, Dimensions } from "react-native";
import { useMemo } from "react";

interface FloatingImage {
  id: number;
  left: number;
  top: number;
  size: number;
  opacity: number;
  rotation: number;
}

export function FloatingBackground() {
  const { width, height } = Dimensions.get("window");

  const floatingImages: FloatingImage[] = useMemo(() => {
    const images: FloatingImage[] = [];
    // Posições fixas para garantir boa distribuição na tela
    const positions = [
      { left: 0.05, top: 0.05, size: 0.28, opacity: 0.18, rot: 15 },
      { left: 0.65, top: 0.02, size: 0.22, opacity: 0.14, rot: -20 },
      { left: 0.75, top: 0.22, size: 0.30, opacity: 0.16, rot: 45 },
      { left: 0.02, top: 0.35, size: 0.20, opacity: 0.12, rot: -35 },
      { left: 0.60, top: 0.45, size: 0.25, opacity: 0.15, rot: 60 },
      { left: 0.10, top: 0.60, size: 0.32, opacity: 0.18, rot: -10 },
      { left: 0.70, top: 0.68, size: 0.24, opacity: 0.13, rot: 30 },
      { left: 0.35, top: 0.75, size: 0.20, opacity: 0.11, rot: -50 },
      { left: 0.80, top: 0.85, size: 0.28, opacity: 0.16, rot: 20 },
      { left: 0.05, top: 0.88, size: 0.22, opacity: 0.13, rot: -25 },
    ];
    positions.forEach((p, i) => {
      images.push({
        id: i,
        left: p.left * width,
        top: p.top * height,
        size: p.size * width,
        opacity: p.opacity,
        rotation: p.rot,
      });
    });
    return images;
  }, [width, height]);

  return (
    <View
      style={{
        position: "absolute",
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
        overflow: "hidden",
        zIndex: 0,
      }}
    >
      {floatingImages.map((img) => (
        <View
          key={img.id}
          style={{
            position: "absolute",
            left: img.left,
            top: img.top,
            width: img.size,
            height: img.size,
            opacity: img.opacity,
            transform: [{ rotate: `${img.rotation}deg` }],
          }}
        >
          <Image
            source={require("@/assets/images/hero_floating.png")}
            style={{
              width: "100%",
              height: "100%",
              resizeMode: "contain",
            }}
          />
        </View>
      ))}
    </View>
  );
}
