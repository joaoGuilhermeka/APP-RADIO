import { BottomTabBarButtonProps } from "@react-navigation/bottom-tabs";
import * as Haptics from "expo-haptics";
import { useRef, useCallback } from "react";
import { Animated, TouchableOpacity, Platform, View } from "react-native";

export function HapticTab(props: BottomTabBarButtonProps) {
  const scale = useRef(new Animated.Value(1)).current;
  const translateY = useRef(new Animated.Value(0)).current;
  const ballScale = useRef(new Animated.Value(0)).current;
  const ballOpacity = useRef(new Animated.Value(0)).current;

  const animatePress = useCallback(() => {
    // Haptic feedback
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }

    // Animação: sobe + encolhe → volta com bounce
    Animated.sequence([
      Animated.parallel([
        Animated.timing(scale, {
          toValue: 0.72,
          duration: 90,
          useNativeDriver: true,
        }),
        Animated.timing(translateY, {
          toValue: -7,
          duration: 90,
          useNativeDriver: true,
        }),
      ]),
      Animated.parallel([
        Animated.spring(scale, {
          toValue: 1,
          friction: 4,
          tension: 220,
          useNativeDriver: true,
        }),
        Animated.spring(translateY, {
          toValue: 0,
          friction: 4,
          tension: 220,
          useNativeDriver: true,
        }),
      ]),
    ]).start();
  }, [scale, translateY]);

  // Animação da bolinha quando está selecionado
  const ballAnimValue = useRef(new Animated.Value(0)).current;

  const animateBall = useCallback((isFocused: boolean) => {
    if (isFocused) {
      Animated.parallel([
        Animated.timing(ballScale, {
          toValue: 1,
          duration: 300,
          useNativeDriver: true,
        }),
        Animated.timing(ballOpacity, {
          toValue: 1,
          duration: 300,
          useNativeDriver: true,
        }),
      ]).start();
    } else {
      Animated.parallel([
        Animated.timing(ballScale, {
          toValue: 0,
          duration: 200,
          useNativeDriver: true,
        }),
        Animated.timing(ballOpacity, {
          toValue: 0,
          duration: 200,
          useNativeDriver: true,
        }),
      ]).start();
    }
  }, [ballScale, ballOpacity]);

  // Atualizar animação quando o foco muda
  if (props.accessibilityState?.selected) {
    animateBall(true);
  } else {
    animateBall(false);
  }

  return (
    <TouchableOpacity
      activeOpacity={1}
      onPress={(e) => {
        animatePress();
        props.onPress?.(e as any);
      }}
      onLongPress={props.onLongPress as any}
      accessibilityRole={props.accessibilityRole}
      accessibilityState={props.accessibilityState}
      accessibilityLabel={props.accessibilityLabel}
      style={[
        { flex: 1, alignItems: "center", justifyContent: "center" },
      ]}
    >
      <View style={{ alignItems: "center", justifyContent: "center", position: "relative" }}>
        {/* Bolinha em cima do ícone */}
        <Animated.View
          style={{
            position: "absolute",
            top: -8,
            width: 12,
            height: 12,
            borderRadius: 6,
            backgroundColor: "#D07600",
            transform: [{ scale: ballScale }],
            opacity: ballOpacity,
            zIndex: 10,
          }}
        />

        {/* Ícone com animação */}
        <Animated.View
          style={{
            transform: [{ scale }, { translateY }],
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          {props.children}
        </Animated.View>
      </View>
    </TouchableOpacity>
  );
}
