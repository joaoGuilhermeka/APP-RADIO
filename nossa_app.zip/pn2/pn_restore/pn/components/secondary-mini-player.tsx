import { View, Text, Image, TouchableOpacity, StyleSheet, Platform } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRadioPlayer } from "@/hooks/use-radio-player";
import { useLiveMusicNow } from "@/hooks/use-live-program-now";
import { useLiveProgram } from "@/hooks/use-live-program";
import { useMusicCover } from "@/hooks/use-music-cover";
import { radioStations } from "@/lib/radio-stations";

// URL padrão da estação principal
const DEFAULT_STREAM_URL = "https://8498.brasilstream.com.br/stream?origem=site";
const DEFAULT_STATION_ID = "barbacena";
const DEFAULT_STATION_NAME = "Nossa Sertaneja";

export function SecondaryMiniPlayer() {
  const { state, play, pause } = useRadioPlayer();
  const isPlaying = state.isPlaying;
  const insets = useSafeAreaInsets();

  // Altura real da tab bar = mesma do _layout.tsx
  const bottomPadding = Platform.OS === "web" ? 12 : Math.max(insets.bottom, 8);
  const tabBarHeight = 70 + bottomPadding;

  const { music: liveMusic } = useLiveMusicNow(isPlaying);
  const { liveProgram } = useLiveProgram();
  const { cover: musicCover } = useMusicCover(liveMusic, () => {});

  const displayTitle = liveMusic || liveProgram?.programa || DEFAULT_STATION_NAME;
  const displaySubtitle = liveProgram?.programa || "AO VIVO";
  const displayImage = musicCover?.coverUrl ||
    (liveProgram?.img && !liveProgram.img.includes("placeholder") ? liveProgram.img : null);

  const handlePlayPause = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    if (isPlaying) {
      await pause();
    } else {
      // Usar a última estação que estava tocando, ou a padrão
      const stationId = state.currentStationId || DEFAULT_STATION_ID;
      const station = radioStations.find(s => s.id === stationId);
      await play(
        stationId,
        station?.streamUrl || DEFAULT_STREAM_URL,
        station?.name || DEFAULT_STATION_NAME
      );
    }
  };

  return (
    <View style={[styles.container, { bottom: tabBarHeight }]}>
      {/* Capa à esquerda */}
      <View style={styles.artContainer}>
        {displayImage ? (
          <Image source={{ uri: displayImage }} style={styles.artImage} resizeMode="cover" />
        ) : (
          <Image source={require("@/assets/images/icon.png")} style={styles.artFallback} resizeMode="contain" />
        )}
      </View>

      {/* Informações no centro */}
      <View style={styles.infoContainer}>
        <Text numberOfLines={1} style={styles.titleText}>
          {displayTitle}
        </Text>
        <Text numberOfLines={1} style={styles.subtitleText}>
          {displaySubtitle}
        </Text>
      </View>

      {/* Botão Play/Pause à direita */}
      <TouchableOpacity
        onPress={handlePlayPause}
        style={styles.playButton}
        hitSlop={{ top: 15, bottom: 15, left: 15, right: 15 }}
      >
        <Ionicons
          name={isPlaying ? "pause" : "play"}
          size={28}
          color="#FFFFFF"
          style={{ marginLeft: isPlaying ? 0 : 3 }}
        />
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: "absolute",
    left: 0,
    right: 0,
    width: "100%",
    height: 58,
    backgroundColor: "#E88924",
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    zIndex: 999,
    elevation: 20,
    borderTopWidth: 1,
    borderTopColor: "rgba(255, 255, 255, 0.25)",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
  },
  artContainer: {
    width: 40,
    height: 40,
    borderRadius: 8,
    overflow: "hidden",
    backgroundColor: "#C96D12",
    alignItems: "center",
    justifyContent: "center",
  },
  artImage: {
    width: "100%",
    height: "100%",
  },
  artFallback: {
    width: 22,
    height: 22,
    opacity: 0.7,
  },
  infoContainer: {
    flex: 1,
    marginHorizontal: 12,
    justifyContent: "center",
  },
  titleText: {
    color: "#FFFFFF",
    fontSize: 15,
    fontWeight: "900",
    letterSpacing: 0.3,
  },
  subtitleText: {
    color: "#FFF3E0",
    fontSize: 12,
    fontWeight: "700",
    marginTop: 2,
    letterSpacing: 0.2,
  },
  playButton: {
    padding: 6,
    alignItems: "center",
    justifyContent: "center",
  },
});
