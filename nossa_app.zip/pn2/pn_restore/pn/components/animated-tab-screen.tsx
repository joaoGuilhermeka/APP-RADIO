import { useEffect, useRef } from "react";
import { Animated, StyleSheet } from "react-native";
import { usePathname } from "expo-router";

interface AnimatedTabScreenProps {
  children: React.ReactNode;
}

/**
 * Envolve o conteúdo de cada aba com uma animação de entrada suave.
 * Ao trocar de aba, a tela desliza levemente de baixo para cima com fade in.
 */
export function AnimatedTabScreen({ children }: AnimatedTabScreenProps) {
  const translateY = useRef(new Animated.Value(18)).current;
  const opacity = useRef(new Animated.Value(0)).current;
  const pathname = usePathname();

  useEffect(() => {
    // Reset para posição inicial
    translateY.setValue(18);
    opacity.setValue(0);

    // Animação de entrada: slide de baixo + fade in
    Animated.parallel([
      Animated.timing(translateY, {
        toValue: 0,
        duration: 280,
        useNativeDriver: true,
      }),
      Animated.timing(opacity, {
        toValue: 1,
        duration: 220,
        useNativeDriver: true,
      }),
    ]).start();
  }, [pathname]);

  return (
    <Animated.View
      style={[
        styles.container,
        {
          opacity,
          transform: [{ translateY }],
        },
      ]}
    >
      {children}
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});
