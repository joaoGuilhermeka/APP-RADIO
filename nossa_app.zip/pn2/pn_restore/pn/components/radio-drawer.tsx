import React, { useEffect } from "react";
import { View, Text, TouchableOpacity, Modal, Pressable, ScrollView, Dimensions, Linking } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Animated, { useSharedValue, useAnimatedStyle, withTiming, Easing } from "react-native-reanimated";

interface RadioDrawerProps {
  visible: boolean;
  onClose: () => void;
}

export function RadioDrawer({ visible, onClose }: RadioDrawerProps) {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { width: screenWidth } = Dimensions.get("window");

  const drawerTranslateX = useSharedValue(-Math.min(screenWidth * 0.75, 320));

  useEffect(() => {
    drawerTranslateX.value = withTiming(
      visible ? 0 : -Math.min(screenWidth * 0.75, 320),
      {
        duration: 300,
        easing: Easing.out(Easing.cubic),
      }
    );
  }, [visible, drawerTranslateX, screenWidth]);

  const animatedDrawerStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: drawerTranslateX.value }],
  }));

  return (
    <Modal
      visible={visible}
      animationType="none"
      transparent
      onRequestClose={onClose}
    >
      <Pressable
        style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)", flexDirection: "row" }}
        onPress={onClose}
      >
        <Animated.View
          style={[
            {
              width: Math.min(screenWidth * 0.75, 320),
              backgroundColor: "#D07600",
              paddingTop: insets.top,
              paddingBottom: insets.bottom,
            },
            animatedDrawerStyle,
          ]}
        >
          <Pressable onPress={(e) => e.stopPropagation()} style={{ flex: 1 }}>
            {/* Cabeçalho com Título NAVEGAÇÃO e Botão X na mesma linha */}
            <View style={{ paddingHorizontal: 20, paddingTop: 16, paddingBottom: 12, flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
              <Text style={{ fontSize: 11, fontWeight: "700", color: "#6B7280", letterSpacing: 1.2, textTransform: "uppercase" }}>
                NAVEGAÇÃO
              </Text>
              <TouchableOpacity onPress={onClose} hitSlop={{ top: 15, bottom: 15, left: 15, right: 15 }}>
                <Ionicons name="close" size={26} color="#1a1a1a" />
              </TouchableOpacity>
            </View>

            <ScrollView contentContainerStyle={{ flexGrow: 1, paddingBottom: 30, paddingTop: 4 }} showsVerticalScrollIndicator={false}>
              {/* Seção NAVEGAÇÃO - Itens */}
              <View style={{ paddingHorizontal: 20, marginBottom: 20 }}>
                <TouchableOpacity
                  onPress={() => {
                    onClose();
                    router.push("/(tabs)");
                  }}
                  style={{ flexDirection: "row", alignItems: "center", paddingVertical: 8, gap: 14 }}
                  activeOpacity={0.7}
                >
                  <View style={{ width: 40, height: 40, borderRadius: 10, backgroundColor: "#D07600", alignItems: "center", justifyContent: "center", shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.2, shadowRadius: 3, elevation: 3 }}>
                    <Ionicons name="home" size={20} color="#FFFFFF" />
                  </View>
                  <Text style={{ fontSize: 16, fontWeight: "600", color: "#1F2937" }}>Início</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  onPress={() => {
                    onClose();
                    router.push("/(tabs)/tv");
                  }}
                  style={{ flexDirection: "row", alignItems: "center", paddingVertical: 8, gap: 14 }}
                  activeOpacity={0.7}
                >
                  <View style={{ width: 40, height: 40, borderRadius: 10, backgroundColor: "#D07600", alignItems: "center", justifyContent: "center", shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.2, shadowRadius: 3, elevation: 3 }}>
                    <Ionicons name="tv" size={20} color="#FFFFFF" />
                  </View>
                  <Text style={{ fontSize: 16, fontWeight: "600", color: "#1F2937" }}>Nossa TV</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  onPress={() => {
                    onClose();
                    router.push("/(tabs)/music");
                  }}
                  style={{ flexDirection: "row", alignItems: "center", paddingVertical: 8, gap: 14 }}
                  activeOpacity={0.7}
                >
                  <View style={{ width: 40, height: 40, borderRadius: 10, backgroundColor: "#D07600", alignItems: "center", justifyContent: "center", shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.2, shadowRadius: 3, elevation: 3 }}>
                    <Ionicons name="musical-notes" size={20} color="#FFFFFF" />
                  </View>
                  <Text style={{ fontSize: 16, fontWeight: "600", color: "#1F2937" }}>Pedidos</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  onPress={() => {
                    onClose();
                    router.push("/(tabs)/whatsapp");
                  }}
                  style={{ flexDirection: "row", alignItems: "center", paddingVertical: 8, gap: 14 }}
                  activeOpacity={0.7}
                >
                  <View style={{ width: 40, height: 40, borderRadius: 10, backgroundColor: "#D07600", alignItems: "center", justifyContent: "center", shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.2, shadowRadius: 3, elevation: 3 }}>
                    <Ionicons name="pricetag" size={20} color="#FFFFFF" />
                  </View>
                  <Text style={{ fontSize: 16, fontWeight: "600", color: "#1F2937" }}>Promoções</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  onPress={() => {
                    onClose();
                    router.push("/(tabs)/news");
                  }}
                  style={{ flexDirection: "row", alignItems: "center", paddingVertical: 8, gap: 14 }}
                  activeOpacity={0.7}
                >
                  <View style={{ width: 40, height: 40, borderRadius: 10, backgroundColor: "#D07600", alignItems: "center", justifyContent: "center", shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.2, shadowRadius: 3, elevation: 3 }}>
                    <Ionicons name="newspaper" size={20} color="#FFFFFF" />
                  </View>
                  <Text style={{ fontSize: 16, fontWeight: "600", color: "#1F2937" }}>Programação</Text>
                </TouchableOpacity>
              </View>

              {/* Seção CONECTE-SE COM A GENTE */}
              <View style={{ paddingHorizontal: 20, paddingTop: 14, borderTopWidth: 1, borderTopColor: "#E5E7EB" }}>
                <Text style={{ fontSize: 11, fontWeight: "700", color: "#6B7280", letterSpacing: 1.2, marginBottom: 12, textTransform: "uppercase" }}>
                  CONECTE-SE COM A GENTE
                </Text>

                <TouchableOpacity
                  onPress={() => Linking.openURL("https://instagram.com/nossasertaneja")}
                  style={{ flexDirection: "row", alignItems: "center", paddingVertical: 8, gap: 14 }}
                  activeOpacity={0.7}
                >
                  <View style={{ width: 40, height: 40, borderRadius: 10, backgroundColor: "#D07600", alignItems: "center", justifyContent: "center", shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.2, shadowRadius: 3, elevation: 3 }}>
                    <Ionicons name="logo-instagram" size={20} color="#FFFFFF" />
                  </View>
                  <Text style={{ fontSize: 16, fontWeight: "600", color: "#1F2937" }}>Instagram</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  onPress={() => Linking.openURL("https://facebook.com/nossasertaneja")}
                  style={{ flexDirection: "row", alignItems: "center", paddingVertical: 8, gap: 14 }}
                  activeOpacity={0.7}
                >
                  <View style={{ width: 40, height: 40, borderRadius: 10, backgroundColor: "#D07600", alignItems: "center", justifyContent: "center", shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.2, shadowRadius: 3, elevation: 3 }}>
                    <Ionicons name="logo-facebook" size={20} color="#FFFFFF" />
                  </View>
                  <Text style={{ fontSize: 16, fontWeight: "600", color: "#1F2937" }}>Facebook</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  onPress={() => Linking.openURL("https://twitter.com/nossasertaneja")}
                  style={{ flexDirection: "row", alignItems: "center", paddingVertical: 8, gap: 14 }}
                  activeOpacity={0.7}
                >
                  <View style={{ width: 40, height: 40, borderRadius: 10, backgroundColor: "#D07600", alignItems: "center", justifyContent: "center", shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.2, shadowRadius: 3, elevation: 3 }}>
                    <Ionicons name="logo-twitter" size={20} color="#FFFFFF" />
                  </View>
                  <Text style={{ fontSize: 16, fontWeight: "600", color: "#1F2937" }}>Twitter</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  onPress={() => Linking.openURL("https://nossasertaneja.com.br")}
                  style={{ flexDirection: "row", alignItems: "center", paddingVertical: 8, gap: 14 }}
                  activeOpacity={0.7}
                >
                  <View style={{ width: 40, height: 40, borderRadius: 10, backgroundColor: "#D07600", alignItems: "center", justifyContent: "center", shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.2, shadowRadius: 3, elevation: 3 }}>
                    <Ionicons name="globe-outline" size={20} color="#FFFFFF" />
                  </View>
                  <Text style={{ fontSize: 16, fontWeight: "600", color: "#1F2937" }}>Site Oficial</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  onPress={() => Linking.openURL("mailto:contato@nossasertaneja.com.br")}
                  style={{ flexDirection: "row", alignItems: "center", paddingVertical: 8, gap: 14 }}
                  activeOpacity={0.7}
                >
                  <View style={{ width: 40, height: 40, borderRadius: 10, backgroundColor: "#D07600", alignItems: "center", justifyContent: "center", shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.2, shadowRadius: 3, elevation: 3 }}>
                    <Ionicons name="mail" size={20} color="#FFFFFF" />
                  </View>
                  <View>
                    <Text style={{ fontSize: 16, fontWeight: "600", color: "#1F2937" }}>Email</Text>
                    <Text style={{ fontSize: 12, color: "#6B7280", marginTop: 1 }}>contato@nossasertaneja.com.br</Text>
                  </View>
                </TouchableOpacity>
              </View>
            </ScrollView>
          </Pressable>
        </Animated.View>
      </Pressable>
    </Modal>
  );
}
