import { useEffect, useRef } from "react";
import { Animated, StyleSheet, useWindowDimensions, StatusBar, Platform } from "react-native";

interface CustomSplashProps {
  onFinish: () => void;
}

export function CustomSplash({ onFinish }: CustomSplashProps) {
  const opacity = useRef(new Animated.Value(1)).current;
  const scale = useRef(new Animated.Value(0.85)).current;
  const { width, height } = useWindowDimensions();

  useEffect(() => {
    // Animação de entrada: logo cresce suavemente
    Animated.spring(scale, {
      toValue: 1,
      friction: 6,
      tension: 80,
      useNativeDriver: true,
    }).start();

    // Após 2 segundos, faz fade out e chama onFinish
    const timer = setTimeout(() => {
      Animated.timing(opacity, {
        toValue: 0,
        duration: 400,
        useNativeDriver: true,
      }).start(() => {
        onFinish();
      });
    }, 2000);

    return () => clearTimeout(timer);
  }, [opacity, scale, onFinish]);

  return (
    <Animated.View style={[styles.container, { opacity }]}>
      <StatusBar hidden />
      <Animated.Image
        source={require("@/assets/images/logo-transparent.png")}
        style={[styles.logo, { width: width * 0.7, height: height * 0.4, transform: [{ scale }] }]}
        resizeMode="contain"
      />
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: "#D07600",
    alignItems: "center",
    justifyContent: "center",
    zIndex: 9999,
    elevation: 9999,
  },
  logo: {
    // width e height definidos dinamicamente via useWindowDimensions
  },
});
