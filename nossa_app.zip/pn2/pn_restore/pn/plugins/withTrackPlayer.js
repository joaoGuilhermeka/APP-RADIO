/**
 * Plugin Expo para configurar react-native-track-player no Android
 *
 * O MusicService já é declarado pelo próprio AndroidManifest do RNTP com exported=true.
 * Este plugin garante apenas as permissões necessárias no manifest principal.
 */
const { withAndroidManifest } = require("@expo/config-plugins");

function withTrackPlayerAndroid(config) {
  return withAndroidManifest(config, async (config) => {
    const androidManifest = config.modResults;
    const manifest = androidManifest.manifest;

    // Garantir que o array de uses-permission existe
    if (!manifest["uses-permission"]) {
      manifest["uses-permission"] = [];
    }

    const existingPermissions = manifest["uses-permission"].map(
      (p) => p.$?.["android:name"]
    );

    const permissionsToAdd = [
      "android.permission.FOREGROUND_SERVICE",
      "android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK",
      "android.permission.WAKE_LOCK",
    ];

    for (const permission of permissionsToAdd) {
      if (!existingPermissions.includes(permission)) {
        manifest["uses-permission"].push({
          $: { "android:name": permission },
        });
      }
    }

    return config;
  });
}

module.exports = withTrackPlayerAndroid;
