export interface Program {
  inicio: string;
  fim: string;
  locutor: string;
  programa: string;
  img: string;
}

export type DayKey = "domingo" | "segunda" | "terca" | "quarta" | "quinta" | "sexta" | "sabado";

export const programacaoSemanal: Record<DayKey, Program[]> = {
  domingo: [
    { inicio: "00:00", fim: "05:00", locutor: "Clube da Insônia", programa: "Clube da Insônia", img: "https://i.postimg.cc/8P0z3gkM/Design-sem-nome-(4).png" },
    { inicio: "05:00", fim: "07:00", locutor: "", programa: "Acorda Sertão", img: "https://i.postimg.cc/sXFTv70g/Design-sem-nome-(1).png" },
    { inicio: "07:00", fim: "09:00", locutor: "", programa: "Programação Completa", img: "https://i.postimg.cc/PxxQ4f8c/programacao.png" },
    { inicio: "09:00", fim: "12:00", locutor: "", programa: "Pede Toca", img: "https://i.postimg.cc/FHkR0MR7/Design-sem-nome-(7).png" },
    { inicio: "12:00", fim: "15:00", locutor: "", programa: "Programação Completa", img: "https://i.postimg.cc/PxxQ4f8c/programacao.png" },
    { inicio: "15:00", fim: "18:00", locutor: "", programa: "Programação Completa", img: "https://i.postimg.cc/PxxQ4f8c/programacao.png" },
    { inicio: "18:00", fim: "00:00", locutor: "", programa: "Programação Completa", img: "https://i.postimg.cc/PxxQ4f8c/programacao.png" },
  ],
  segunda: [
    { inicio: "00:00", fim: "05:00", locutor: "", programa: "Clube da Insônia", img: "https://i.postimg.cc/8P0z3gkM/Design-sem-nome-(4).png" },
    { inicio: "05:00", fim: "07:00", locutor: "", programa: "Acorda Sertão", img: "https://i.postimg.cc/sXFTv70g/Design-sem-nome-(1).png" },
    { inicio: "07:00", fim: "12:00", locutor: "Kabellinho", programa: "Nossa Manhã", img: "https://i.postimg.cc/D0gQtpWr/TEMA-NOSSA-MANHA.png" },
    { inicio: "12:00", fim: "13:00", locutor: "", programa: "Clássicos Nossa Sertaneja", img: "https://i.postimg.cc/SNq6s8cG/Design-sem-nome-(3).png" },
    { inicio: "13:00", fim: "18:00", locutor: "Renatinha Cordeiro", programa: "Tarde Show", img: "https://i.postimg.cc/SKNB5HJ6/TEMA-NOSSA-MANHA-(1).png" },
    { inicio: "18:00", fim: "19:00", locutor: "", programa: "As mais pedidas do dia", img: "https://i.postimg.cc/5yj6Y4Nz/Design-sem-nome-(5).png" },
    { inicio: "19:00", fim: "20:00", locutor: "", programa: "Voz do Brasil", img: "https://i.postimg.cc/CLvnvY0Q/Design-sem-nome.png" },
    { inicio: "20:00", fim: "22:00", locutor: "Henrique Barbosa", programa: "Buteco Nossa Sertaneja", img: "https://i.postimg.cc/FR1Qfwv9/TEMA-NOSSA-MANHA-(2).png" },
    { inicio: "22:00", fim: "00:00", locutor: "Henrique Barbosa", programa: "Love Nossa Sertaneja", img: "https://i.postimg.cc/bJP3Wt69/TEMA-NOSSA-MANHA-(3).png" },
  ],
  terca: [
    { inicio: "00:00", fim: "05:00", locutor: "", programa: "Clube da Insônia", img: "https://i.postimg.cc/8P0z3gkM/Design-sem-nome-(4).png" },
    { inicio: "05:00", fim: "07:00", locutor: "", programa: "Acorda Sertão", img: "https://i.postimg.cc/sXFTv70g/Design-sem-nome-(1).png" },
    { inicio: "07:00", fim: "12:00", locutor: "Kabellinho", programa: "Nossa Manhã", img: "https://i.postimg.cc/D0gQtpWr/TEMA-NOSSA-MANHA.png" },
    { inicio: "12:00", fim: "13:00", locutor: "", programa: "Clássicos Nossa Sertaneja", img: "https://i.postimg.cc/SNq6s8cG/Design-sem-nome-(3).png" },
    { inicio: "13:00", fim: "18:00", locutor: "Renatinha Cordeiro", programa: "Tarde Show", img: "https://i.postimg.cc/SKNB5HJ6/TEMA-NOSSA-MANHA-(1).png" },
    { inicio: "18:00", fim: "19:00", locutor: "", programa: "As mais pedidas do dia", img: "https://i.postimg.cc/5yj6Y4Nz/Design-sem-nome-(5).png" },
    { inicio: "19:00", fim: "20:00", locutor: "", programa: "Voz do Brasil", img: "https://i.postimg.cc/CLvnvY0Q/Design-sem-nome.png" },
    { inicio: "20:00", fim: "22:00", locutor: "Henrique Barbosa", programa: "Buteco Nossa Sertaneja", img: "https://i.postimg.cc/FR1Qfwv9/TEMA-NOSSA-MANHA-(2).png" },
    { inicio: "22:00", fim: "00:00", locutor: "Henrique Barbosa", programa: "Love Nossa Sertaneja", img: "https://i.postimg.cc/bJP3Wt69/TEMA-NOSSA-MANHA-(3).png" },
  ],
  quarta: [
    { inicio: "00:00", fim: "05:00", locutor: "", programa: "Clube da Insônia", img: "https://i.postimg.cc/8P0z3gkM/Design-sem-nome-(4).png" },
    { inicio: "05:00", fim: "07:00", locutor: "", programa: "Acorda Sertão", img: "https://i.postimg.cc/sXFTv70g/Design-sem-nome-(1).png" },
    { inicio: "07:00", fim: "12:00", locutor: "Kabellinho", programa: "Nossa Manhã", img: "https://i.postimg.cc/D0gQtpWr/TEMA-NOSSA-MANHA.png" },
    { inicio: "12:00", fim: "13:00", locutor: "", programa: "Clássicos Nossa Sertaneja", img: "https://i.postimg.cc/SNq6s8cG/Design-sem-nome-(3).png" },
    { inicio: "13:00", fim: "18:00", locutor: "Renatinha Cordeiro", programa: "Tarde Show", img: "https://i.postimg.cc/SKNB5HJ6/TEMA-NOSSA-MANHA-(1).png" },
    { inicio: "18:00", fim: "19:00", locutor: "", programa: "As mais pedidas do dia", img: "https://i.postimg.cc/5yj6Y4Nz/Design-sem-nome-(5).png" },
    { inicio: "19:00", fim: "20:00", locutor: "", programa: "Voz do Brasil", img: "https://i.postimg.cc/CLvnvY0Q/Design-sem-nome.png" },
    { inicio: "20:00", fim: "22:00", locutor: "Henrique Barbosa", programa: "Buteco Nossa Sertaneja", img: "https://i.postimg.cc/FR1Qfwv9/TEMA-NOSSA-MANHA-(2).png" },
    { inicio: "22:00", fim: "00:00", locutor: "Henrique Barbosa", programa: "Love Nossa Sertaneja", img: "https://i.postimg.cc/bJP3Wt69/TEMA-NOSSA-MANHA-(3).png" },
  ],
  quinta: [
    { inicio: "00:00", fim: "05:00", locutor: "", programa: "Clube da Insônia", img: "https://i.postimg.cc/8P0z3gkM/Design-sem-nome-(4).png" },
    { inicio: "05:00", fim: "07:00", locutor: "", programa: "Acorda Sertão", img: "https://i.postimg.cc/sXFTv70g/Design-sem-nome-(1).png" },
    { inicio: "07:00", fim: "12:00", locutor: "Kabellinho", programa: "Nossa Manhã", img: "https://i.postimg.cc/D0gQtpWr/TEMA-NOSSA-MANHA.png" },
    { inicio: "12:00", fim: "13:00", locutor: "", programa: "Clássicos Nossa Sertaneja", img: "https://i.postimg.cc/SNq6s8cG/Design-sem-nome-(3).png" },
    { inicio: "13:00", fim: "18:00", locutor: "Renatinha Cordeiro", programa: "Tarde Show", img: "https://i.postimg.cc/SKNB5HJ6/TEMA-NOSSA-MANHA-(1).png" },
    { inicio: "18:00", fim: "19:00", locutor: "", programa: "As mais pedidas do dia", img: "https://i.postimg.cc/5yj6Y4Nz/Design-sem-nome-(5).png" },
    { inicio: "19:00", fim: "20:00", locutor: "", programa: "Voz do Brasil", img: "https://i.postimg.cc/CLvnvY0Q/Design-sem-nome.png" },
    { inicio: "20:00", fim: "22:00", locutor: "Henrique Barbosa", programa: "Buteco Nossa Sertaneja", img: "https://i.postimg.cc/FR1Qfwv9/TEMA-NOSSA-MANHA-(2).png" },
    { inicio: "22:00", fim: "00:00", locutor: "Henrique Barbosa", programa: "Love Nossa Sertaneja", img: "https://i.postimg.cc/bJP3Wt69/TEMA-NOSSA-MANHA-(3).png" },
  ],
  sexta: [
    { inicio: "00:00", fim: "05:00", locutor: "", programa: "Clube da Insônia", img: "https://i.postimg.cc/8P0z3gkM/Design-sem-nome-(4).png" },
    { inicio: "05:00", fim: "07:00", locutor: "", programa: "Acorda Sertão", img: "https://i.postimg.cc/sXFTv70g/Design-sem-nome-(1).png" },
    { inicio: "07:00", fim: "12:00", locutor: "Kabellinho", programa: "Nossa Manhã", img: "https://i.postimg.cc/D0gQtpWr/TEMA-NOSSA-MANHA.png" },
    { inicio: "12:00", fim: "13:00", locutor: "", programa: "Clássicos Nossa Sertaneja", img: "https://i.postimg.cc/SNq6s8cG/Design-sem-nome-(3).png" },
    { inicio: "13:00", fim: "18:00", locutor: "Renatinha Cordeiro", programa: "Tarde Show", img: "https://i.postimg.cc/SKNB5HJ6/TEMA-NOSSA-MANHA-(1).png" },
    { inicio: "18:00", fim: "19:00", locutor: "", programa: "As mais pedidas do dia", img: "https://i.postimg.cc/5yj6Y4Nz/Design-sem-nome-(5).png" },
    { inicio: "19:00", fim: "20:00", locutor: "", programa: "Voz do Brasil", img: "https://i.postimg.cc/CLvnvY0Q/Design-sem-nome.png" },
    { inicio: "20:00", fim: "22:00", locutor: "Henrique Barbosa", programa: "Buteco Nossa Sertaneja", img: "https://i.postimg.cc/FR1Qfwv9/TEMA-NOSSA-MANHA-(2).png" },
    { inicio: "22:00", fim: "00:00", locutor: "Henrique Barbosa", programa: "Love Nossa Sertaneja", img: "https://i.postimg.cc/bJP3Wt69/TEMA-NOSSA-MANHA-(3).png" },
  ],
  sabado: [
    { inicio: "00:00", fim: "05:00", locutor: "", programa: "Clube da Insônia", img: "https://i.postimg.cc/8P0z3gkM/Design-sem-nome-(4).png" },
    { inicio: "05:00", fim: "07:00", locutor: "", programa: "Acorda Sertão", img: "https://i.postimg.cc/sXFTv70g/Design-sem-nome-(1).png" },
    { inicio: "07:00", fim: "12:00", locutor: "Kabellinho", programa: "Nossa Manhã", img: "imagens/kabello.png" },
    { inicio: "12:00", fim: "13:00", locutor: "", programa: "Clássicos Nossa Sertaneja", img: "https://i.postimg.cc/SNq6s8cG/Design-sem-nome-(3).png" },
    { inicio: "13:00", fim: "18:00", locutor: "Renatinha Cordeiro", programa: "Tarde Show", img: "https://i.postimg.cc/SKNB5HJ6/TEMA-NOSSA-MANHA-(1).png" },
    { inicio: "18:00", fim: "19:00", locutor: "", programa: "As mais pedidas do dia", img: "https://i.postimg.cc/5yj6Y4Nz/Design-sem-nome-(5).png" },
    { inicio: "19:00", fim: "20:00", locutor: "", programa: "Voz do Brasil", img: "https://i.postimg.cc/CLvnvY0Q/Design-sem-nome.png" },
    { inicio: "20:00", fim: "00:00", locutor: "Henrique Barbosa", programa: "Buteco Nossa Sertaneja", img: "https://i.postimg.cc/FR1Qfwv9/TEMA-NOSSA-MANHA-(2).png" },
  ],
};

export const dayLabels: { key: DayKey; label: string }[] = [
  { key: "domingo", label: "DOM" },
  { key: "segunda", label: "SEG" },
  { key: "terca", label: "TER" },
  { key: "quarta", label: "QUA" },
  { key: "quinta", label: "QUI" },
  { key: "sexta", label: "SEX" },
  { key: "sabado", label: "SAB" },
];

export function getCurrentDayKey(): DayKey {
  const days: DayKey[] = ["domingo", "segunda", "terca", "quarta", "quinta", "sexta", "sabado"];
  return days[new Date().getDay()];
}

export function getCurrentProgram(day: DayKey): Program | null {
  const now = new Date();
  const currentTime = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
  const programs = programacaoSemanal[day];
  for (const p of programs) {
    if (p.fim === "00:00") {
      if (currentTime >= p.inicio) return p;
    } else {
      if (currentTime >= p.inicio && currentTime < p.fim) return p;
    }
  }
  return programs[0] ?? null;
}
