export interface RadioStation {
  id: string;
  name: string;
  city: string;
  frequency: string;
  streamUrl: string;
  statsUrl: string;
}

export const radioStations: RadioStation[] = [
  {
    id: "barbacena",
    name: "BARBACENA",
    city: "Barbacena",
    frequency: "99.7 FM",
    streamUrl: "https://8500.brasilstream.com.br/stream?origem=site",
    statsUrl: "https://8500.brasilstream.com.br/status",
  },
  {
    id: "pradopolis",
    name: "PRADÓPOLIS",
    city: "Pradópolis",
    frequency: "88.5 FM",
    streamUrl: "https://8514.brasilstream.com.br/stream?origem=site",
    statsUrl: "https://8514.brasilstream.com.br/status",
  },
  {
    id: "paracatu",
    name: "PARACATU",
    city: "Paracatu",
    frequency: "97.3 FM",
    streamUrl: "https://8498.brasilstream.com.br/stream?origem=site",
    statsUrl: "https://8498.brasilstream.com.br/status",
  },
  {
    id: "bueno-brandao",
    name: "BUENO BRANDÃO",
    city: "Bueno Brandão",
    frequency: "102.5 FM",
    streamUrl: "https://8502.brasilstream.com.br/stream?origem=site",
    statsUrl: "https://8502.brasilstream.com.br/status",
  },
  {
    id: "lambari",
    name: "LAMBARI",
    city: "Lambari",
    frequency: "107.1 FM",
    streamUrl: "https://8504.brasilstream.com.br/stream?origem=site",
    statsUrl: "https://8504.brasilstream.com.br/status",
  },
  {
    id: "sete-lagoas",
    name: "SETE LAGOAS",
    city: "Sete Lagoas",
    frequency: "107.7 FM",
    streamUrl: "https://8516.brasilstream.com.br/stream?origem=site",
    statsUrl: "https://8516.brasilstream.com.br/status",
  },
];
