import { NativeModules, Platform } from "react-native";

/**
 * Bridge TypeScript para AudioService nativo Android
 * 
 * Permite chamar o serviço Android de MediaSession desde JavaScript
 */

interface AudioServiceModule {
  playStream(
    url: string,
    title: string,
    artist: string,
    artworkUrl?: string
  ): Promise<void>;
  pause(): Promise<void>;
  resume(): Promise<void>;
  stop(): Promise<void>;
}

// Fallback para web/iOS
const fallbackModule: AudioServiceModule = {
  playStream: async () => {
    console.warn("[AudioService] playStream não disponível nesta plataforma");
  },
  pause: async () => {
    console.warn("[AudioService] pause não disponível nesta plataforma");
  },
  resume: async () => {
    console.warn("[AudioService] resume não disponível nesta plataforma");
  },
  stop: async () => {
    console.warn("[AudioService] stop não disponível nesta plataforma");
  },
};

// Obter módulo nativo ou fallback
const AudioServiceModule: AudioServiceModule =
  Platform.OS === "android"
    ? NativeModules.AudioServiceModule || fallbackModule
    : fallbackModule;

export default AudioServiceModule;
