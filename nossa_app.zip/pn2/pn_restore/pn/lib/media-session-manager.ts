import { Platform, AppState, type AppStateStatus } from "react-native";
import { useAudioPlayer, type AudioPlayer } from "expo-audio";

/**
 * MediaSessionManager - Singleton Pattern
 * 
 * Garante que existe apenas UMA Media Session ativa por vez.
 * Previne múltiplas sessões acumuladas ao abrir/fechar o app.
 * 
 * Responsabilidades:
 * 1. Criar e reutilizar player (não criar múltiplos)
 * 2. Gerenciar ciclo de vida do player
 * 3. Cleanup agressivo ao fechar app
 * 4. Sincronizar estado entre múltiplas instâncias do hook
 */

interface MediaSessionState {
  player: AudioPlayer | null;
  isInitialized: boolean;
  appState: AppStateStatus;
  lockScreenActive: boolean;
}

class MediaSessionManager {
  private static instance: MediaSessionManager;
  private state: MediaSessionState = {
    player: null,
    isInitialized: false,
    appState: "active",
    lockScreenActive: false,
  };

  private listeners: Set<() => void> = new Set();
  private appStateSubscription: any = null;

  private constructor() {
    if (Platform.OS === "web") return;
    this.initializeAppStateListener();
  }

  /**
   * Obter instância única do gerenciador
   */
  static getInstance(): MediaSessionManager {
    if (!MediaSessionManager.instance) {
      MediaSessionManager.instance = new MediaSessionManager();
    }
    return MediaSessionManager.instance;
  }

  /**
   * Inicializar listener de AppState
   * Detecta quando o app é fechado/removido da multitarefa
   */
  private initializeAppStateListener() {
    if (this.appStateSubscription) return; // Já inicializado

    this.appStateSubscription = AppState.addEventListener(
      "change",
      this.handleAppStateChange.bind(this)
    );
  }

  /**
   * Lidar com mudanças de estado do app
   */
  private handleAppStateChange(nextAppState: AppStateStatus) {
    const previousState = this.state.appState;
    this.state.appState = nextAppState;

    // Detectar transições importantes
    const isBeingClosed = previousState === "active" && nextAppState === "unknown";
    const isBeingMinimized =
      previousState === "active" &&
      (nextAppState === "inactive" || nextAppState === "background");
    const isBeingResumed = previousState !== "active" && nextAppState === "active";

    // App foi removido da multitarefa ou encerrado
    if (isBeingClosed) {
      console.log("[MediaSessionManager] App sendo fechado/removido da multitarefa");
      this.destroySession();
    }

    // App foi minimizado (manter Media Session ativa)
    if (isBeingMinimized) {
      console.log("[MediaSessionManager] App minimizado");
      // Não fazer nada - deixar tocando em background
    }

    // App foi retomado
    if (isBeingResumed) {
      console.log("[MediaSessionManager] App retomado");
      // Notificar listeners para atualizar UI se necessário
      this.notifyListeners();
    }
  }

  /**
   * Obter ou criar player
   * Sempre retorna a mesma instância (Singleton)
   */
  getOrCreatePlayer(): AudioPlayer {
    if (!this.state.player) {
      console.log("[MediaSessionManager] Criando novo player");
      this.state.player = useAudioPlayer("");
      this.state.isInitialized = true;
    }
    return this.state.player;
  }

  /**
   * Verificar se player já existe
   */
  hasPlayer(): boolean {
    return this.state.player !== null;
  }

  /**
   * Obter player atual (sem criar se não existir)
   */
  getCurrentPlayer(): AudioPlayer | null {
    return this.state.player;
  }

  /**
   * Atualizar estado de lock screen
   */
  setLockScreenActive(active: boolean) {
    this.state.lockScreenActive = active;
  }

  /**
   * Verificar se lock screen está ativo
   */
  isLockScreenActive(): boolean {
    return this.state.lockScreenActive;
  }

  /**
   * Destruir Media Session completamente
   * Chamado quando app é fechado/removido da multitarefa
   */
  private destroySession() {
    console.log("[MediaSessionManager] Destruindo Media Session");

    if (!this.state.player) {
      console.log("[MediaSessionManager] Nenhum player para destruir");
      return;
    }

    try {
      // 1. Pausar reprodução
      try {
        this.state.player.pause();
        console.log("[MediaSessionManager] Player pausado");
      } catch (e) {
        console.warn("[MediaSessionManager] Erro ao pausar:", e);
      }

      // 2. Limpar lock screen (remove notificação de mídia)
      try {
        this.state.player.clearLockScreenControls();
        console.log("[MediaSessionManager] Lock screen limpo");
      } catch (e) {
        console.warn("[MediaSessionManager] Erro ao limpar lock screen:", e);
      }

      // 3. Remover player (libera recursos)
      try {
        this.state.player.remove();
        console.log("[MediaSessionManager] Player removido");
      } catch (e) {
        console.warn("[MediaSessionManager] Erro ao remover player:", e);
      }

      // 4. Reset de estado
      this.state.player = null;
      this.state.isInitialized = false;
      this.state.lockScreenActive = false;

      console.log("[MediaSessionManager] Media Session destruída completamente");
    } catch (error) {
      console.error("[MediaSessionManager] Erro crítico ao destruir sessão:", error);
    }
  }

  /**
   * Cleanup manual (chamado quando hook é desmontado)
   */
  cleanup() {
    console.log("[MediaSessionManager] Cleanup manual chamado");
    this.destroySession();
  }

  /**
   * Registrar listener para mudanças de estado
   */
  subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  /**
   * Notificar todos os listeners
   */
  private notifyListeners() {
    this.listeners.forEach((listener) => listener());
  }

  /**
   * Destruir gerenciador (cleanup final)
   */
  destroy() {
    console.log("[MediaSessionManager] Destruindo gerenciador");
    this.destroySession();

    if (this.appStateSubscription) {
      this.appStateSubscription.remove();
      this.appStateSubscription = null;
    }

    this.listeners.clear();
  }
}

export const mediaSessionManager = MediaSessionManager.getInstance();
