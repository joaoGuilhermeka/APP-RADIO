import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { join } from "node:path";

const projectRoot = join(__dirname, "..");

function readProjectFile(relativePath: string) {
  return readFileSync(join(projectRoot, relativePath), "utf8");
}

describe("Visual theme updates - Nossa Sertaneja", () => {
  it("uses #D07600 instead of the previous orange brand color", () => {
    const files = [
      "app.config.ts",
      "app/_layout.tsx",
      "app/(tabs)/_layout.tsx",
      "app/(tabs)/index.tsx",
      "app/(tabs)/music.tsx",
      "app/(tabs)/news.tsx",
      "app/(tabs)/promotions.tsx",
      "app/(tabs)/tv.tsx",
      "app/(tabs)/whatsapp.tsx",
      "components/custom-splash.tsx",
      "components/haptic-tab.tsx",
      "theme.config.js",
    ];

    for (const file of files) {
      const source = readProjectFile(file);
      expect(source, file).not.toMatch(/#ea974b/i);
    }

    expect(readProjectFile("theme.config.js")).toContain("#D07600");
  });

  it("keeps the bottom tab bar with #D07600, white inactive, black active, and horizontal schedule selector", () => {
    const layoutSource = readProjectFile("app/(tabs)/_layout.tsx");
    const newsSource = readProjectFile("app/(tabs)/news.tsx");
    const scheduleSource = readProjectFile("lib/programming-schedule.ts");
    const indexSource = readProjectFile("app/(tabs)/index.tsx");

    expect(layoutSource).toContain('backgroundColor: "#D07600"');
    expect(layoutSource).toContain('tabBarActiveTintColor: "#000000"');
    expect(layoutSource).toContain('Nossa TV');
    expect(newsSource).toContain('horizontal');
    expect(scheduleSource).toContain('Clube da Insônia');
    expect(indexSource).toContain('Nossa TV');
    expect(indexSource).toContain('Pedidos');
  });

  it("keeps like and dislike touch targets responsive without a circular background", () => {
    const source = readProjectFile("app/(tabs)/index.tsx");
    const reactionsSection = source.slice(
      source.indexOf("{/* Controles - Like, Dislike, Play/Pause */}"),
      source.indexOf("{/* Toast de Feedback */}"),
    );

    expect(source).toContain("const likeDislikeSize = 60");
    expect(reactionsSection).toContain('name={vote === "like" ? "thumbs-up" : "thumbs-up-outline"}');
    expect(reactionsSection).toContain('name={vote === "dislike" ? "thumbs-down" : "thumbs-down-outline"}');
    expect(reactionsSection).not.toContain('backgroundColor: "#1a1a1a"');
    expect(reactionsSection).not.toContain("borderRadius: likeDislikeSize / 2");
  });
});
