import { describe, it, expect } from "vitest";

// Função de decodificação (copiada do index.tsx para teste)
const decodeHtmlEntities = (text: string): string => {
  if (!text) return text;
  const entities: { [key: string]: string } = {
    "&amp;": "&",
    "&lt;": "<",
    "&gt;": ">",
    "&quot;": '"',
    "&#39;": "'",
    "&apos;": "'",
    "&nbsp;": " ",
    "&copy;": "©",
    "&reg;": "®",
    "&trade;": "™",
  };
  let decoded = text;
  Object.entries(entities).forEach(([entity, char]) => {
    decoded = decoded.replace(new RegExp(entity, "g"), char);
  });
  return decoded;
};

describe("HTML Entity Decoding", () => {
  it("should decode &amp; to &", () => {
    expect(decodeHtmlEntities("Banda &amp; Orquestra")).toBe("Banda & Orquestra");
  });

  it("should decode &quot; to double quote", () => {
    expect(decodeHtmlEntities('Música &quot;Clássica&quot;')).toBe('Música "Clássica"');
  });

  it("should decode &#39; to single quote", () => {
    expect(decodeHtmlEntities("It&#39;s a Song")).toBe("It's a Song");
  });

  it("should decode &lt; and &gt;", () => {
    expect(decodeHtmlEntities("&lt;Intro&gt;")).toBe("<Intro>");
  });

  it("should decode multiple entities in one string", () => {
    expect(decodeHtmlEntities("Artista &amp; Banda &quot;The Best&quot;")).toBe(
      'Artista & Banda "The Best"'
    );
  });

  it("should handle empty strings", () => {
    expect(decodeHtmlEntities("")).toBe("");
  });

  it("should handle strings with no entities", () => {
    expect(decodeHtmlEntities("Normal Song Title")).toBe("Normal Song Title");
  });

  it("should decode copyright symbol", () => {
    expect(decodeHtmlEntities("&copy; 2024")).toBe("© 2024");
  });

  it("should decode registered trademark", () => {
    expect(decodeHtmlEntities("Brand&reg;")).toBe("Brand®");
  });

  it("should decode trade mark", () => {
    expect(decodeHtmlEntities("Product&trade;")).toBe("Product™");
  });

  it("should handle multiple occurrences of same entity", () => {
    expect(decodeHtmlEntities("&amp;&amp;&amp;")).toBe("&&&");
  });
});
