# Design - Nossa Sertaneja Rádio

## Visão Geral
Aplicativo móvel para ouvir estações de rádio de diferentes praças, com interface intuitiva e players de áudio integrados. O design segue os padrões iOS HIG com foco em uso com uma mão.

## Telas Principais

### 1. Home Screen (Lista de Estações)
**Conteúdo Principal:**
- Logo da marca no topo (Nossa Sertaneja)
- Lista vertical de todas as 7 estações de rádio
- Cada estação exibida como um card com:
  - Nome da estação (ex: "BARBACENA 99.7 FM")
  - Frequência em destaque
  - Ícone de play/pause
  - Indicador visual de "ao vivo" (pulsante quando tocando)

**Funcionalidade:**
- Tap em um card abre o player detalhado
- Feedback visual ao tocar (opacity 0.7)
- Scroll suave entre estações

### 2. Player Detail Screen
**Conteúdo Principal:**
- Logo grande da estação/marca no topo
- Nome e frequência da estação em destaque
- Visualizador de áudio (animação de ondas ou barras)
- Controles de player:
  - Botão Play/Pause (grande, centro)
  - Botão Voltar (voltar para lista)
  - Indicador de status (conectando, tocando, pausado)

**Funcionalidade:**
- Play/Pause com haptic feedback
- Mostrar status de conexão
- Permitir voltar para lista de estações

## Paleta de Cores
- **Primary (Laranja):** #FF8C00 - Botões e destaques (combina com logo)
- **Background:** #FFFFFF (light) / #151718 (dark)
- **Surface:** #F5F5F5 (light) / #1E2022 (dark)
- **Foreground:** #11181C (light) / #ECEDEE (dark)
- **Muted:** #687076 (light) / #9BA1A6 (dark)
- **Border:** #E5E7EB (light) / #334155 (dark)

## Fluxos Principais

### Fluxo 1: Ouvir uma Estação
1. Usuário abre o app na Home Screen
2. Vê lista de todas as 7 estações
3. Tap em uma estação → abre Player Detail Screen
4. Tap em Play → áudio começa a tocar
5. Tap em Pause → áudio pausa
6. Tap em Voltar → retorna à Home Screen

### Fluxo 2: Trocar de Estação
1. Usuário está na Home Screen
2. Tap em outra estação → abre seu player
3. Áudio anterior para, novo áudio começa

## Considerações de Design
- **Orientação:** Portrait (9:16)
- **Uso com uma mão:** Botões principais no centro/inferior
- **Acessibilidade:** Texto legível, contraste adequado
- **Feedback:** Haptic feedback em ações principais (play/pause)
- **Performance:** Transições suaves, sem lag ao trocar estações
